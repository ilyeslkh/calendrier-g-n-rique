package fr.univlille.iut.gestionnaireplanning.inputmodels;

public class UserDto {

}
