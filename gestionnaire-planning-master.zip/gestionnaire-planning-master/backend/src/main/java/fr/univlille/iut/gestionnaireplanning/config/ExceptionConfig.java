package fr.univlille.iut.gestionnaireplanning.config;

import jakarta.validation.ConstraintViolationException;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.annotation.ExceptionHandler;

@Configuration
public class ExceptionConfig {
    @ExceptionHandler(ConstraintViolationException.class)
    public ProblemDetail details(ConstraintViolationException erreur) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, erreur.getMessage());
    }
}
