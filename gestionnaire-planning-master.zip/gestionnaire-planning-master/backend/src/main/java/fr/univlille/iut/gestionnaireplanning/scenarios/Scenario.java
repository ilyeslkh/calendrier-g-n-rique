package fr.univlille.iut.gestionnaireplanning.scenarios;

import fr.univlille.iut.gestionnaireplanning.model.ServiceConfig;
import fr.univlille.iut.gestionnaireplanning.model.WeeklyTimeSlots;

import java.io.InputStream;
import java.util.Set;

public interface Scenario {
    ServiceConfig getConfig();
    Set<WeeklyTimeSlots> getWeeklyTimeSlots();
    InputStream getImageStream();
}
