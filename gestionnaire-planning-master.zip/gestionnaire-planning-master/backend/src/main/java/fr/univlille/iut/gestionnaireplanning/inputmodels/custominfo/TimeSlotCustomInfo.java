package fr.univlille.iut.gestionnaireplanning.inputmodels.custominfo;

public interface TimeSlotCustomInfo {
}
