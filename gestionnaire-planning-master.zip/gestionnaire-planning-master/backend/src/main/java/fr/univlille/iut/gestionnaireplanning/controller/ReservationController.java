package fr.univlille.iut.gestionnaireplanning.controller;

import fr.univlille.iut.gestionnaireplanning.inputmodels.UserReservationsDTO;
import fr.univlille.iut.gestionnaireplanning.model.Reservations;
import fr.univlille.iut.gestionnaireplanning.inputmodels.ReservationsDTO;
import fr.univlille.iut.gestionnaireplanning.model.TimeSlots;
import fr.univlille.iut.gestionnaireplanning.model.Users;
import fr.univlille.iut.gestionnaireplanning.services.*;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/reservations")
public class ReservationController {
    private final ReservationService reservationService;
    private final TimeSlotsService tsService;
    private final TokenService token;
    private final UsersService usersService;
    private final EmailService email;


    public ReservationController(ReservationService reservationService, TimeSlotsService timeSlotsService, TokenService token, UsersService usersService, EmailService email) {
        this.reservationService = reservationService;
        this.tsService = timeSlotsService;
        this.token = token;
        this.usersService = usersService;
        this.email = email;
    }

    @PostMapping()
    @Transactional
    public Reservations postReservations(@Valid @RequestBody ReservationsDTO reservationInfos) {
        if (this.token.isAdmin()) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Vous ne pouvez pas réserver en tant qu'administrateur");
        }

        TimeSlots timeSlot = tsService.findOrCreate(reservationInfos.getDate(), reservationInfos.getStartHour());

        Reservations res = reservationService.createReservation(timeSlot, reservationInfos.getNbPersons(), token.getUserId());
        email.sendFromReservation(res);
        return res;
    }
    @GetMapping()
    public List<UserReservationsDTO> getReservations(@RequestParam() String filter) {
        Users user = usersService.getUserById(token.getUserId());
        if (filter.equals("current")) {
            return reservationService.getCurrentReservationByUser(user).stream().limit(50).collect(Collectors.toList());
        } else if (filter.equals("past")) {
            return reservationService.getPastReservationByUser(user).stream().limit(50).collect(Collectors.toList());
        } else {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "filter doesn't exists");
        }
    }

    @PatchMapping(path = "/{id}")
    public Reservations patchReservation(@PathVariable() int id, @Valid @RequestBody() Reservations toModify) {
        Reservations reservation = reservationService.findById(id);
        if (reservation.getUser().getId() != token.getUserId() && !token.isAdmin()) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Vous ne pouvez pas supprimer la réservation d'une autre personne!");
        }
        if (tsService.hasDatePassed(reservation.getTimeSlotId().getStartDate(), reservation.getTimeSlotId().getStartHour())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Le créneau est déjà passé!");
        }
        if (toModify.isCancelled()) {
            reservation.setCancelled(true);
            if (toModify.getCancelReason() != null && !toModify.getCancelReason().isEmpty())
                reservation.setCancelReason(toModify.getCancelReason());
        } else {
            reservation.setNbPersons(toModify.getNbPersons());
        }
        reservationService.save(reservation);
        if (toModify.isCancelled()) {
            email.cancelFromReservation(reservation);
        }
        return reservation;
    }
}

