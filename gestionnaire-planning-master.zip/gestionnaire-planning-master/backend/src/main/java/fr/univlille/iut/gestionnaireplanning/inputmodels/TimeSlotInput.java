package fr.univlille.iut.gestionnaireplanning.inputmodels;

    import java.time.LocalTime;

public interface TimeSlotInput {
    LocalTime getStartHour();
    boolean getIsCancelled();
    int getNbPersons();
}
