package fr.univlille.iut.gestionnaireplanning.inputmodels;

import fr.univlille.iut.gestionnaireplanning.inputmodels.custominfo.TimeSlotCustomInfo;
import fr.univlille.iut.gestionnaireplanning.model.Reservations;
import fr.univlille.iut.gestionnaireplanning.model.TimeSlots;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;

import java.sql.Date;
import java.time.LocalTime;

@Data
public class TimeSlotOutput {
    public enum ResponseType {
        NOT_RESERVED, RESERVED, ADMIN
    }

    private Integer id;
    private Date startDate;
    private LocalTime startHour;
    private boolean isCancelled;
    private String cancelReason;
    private int nbPersons;
    @Enumerated(EnumType.STRING)
    private ResponseType responseType;
    private TimeSlotCustomInfo customInfo;

    private TimeSlotOutput(Integer id, Date startDate, LocalTime startHour, int nbPersons) {
        this.id = id;
        this.startDate = startDate;
        this.startHour = startHour;
        this.isCancelled = false;
        this.nbPersons = nbPersons;
        this.responseType = ResponseType.NOT_RESERVED;
    }

    public TimeSlotOutput(TimeSlots timeSlot) {
        this(timeSlot.getId(),
             timeSlot.getStartDate(),
             timeSlot.getStartHour(),
             timeSlot.getReservations().stream()
                                        .filter(r-> !r.isCancelled())
                                        .mapToInt(Reservations::getNbPersons)
                                        .sum()
        );
        this.isCancelled = timeSlot.isCancelled();
        this.cancelReason = timeSlot.getCancelReason();
    }

    public TimeSlotOutput(Integer id, Date startDate, LocalTime startHour) {
        this(id, startDate, startHour, 0);
    }
}
