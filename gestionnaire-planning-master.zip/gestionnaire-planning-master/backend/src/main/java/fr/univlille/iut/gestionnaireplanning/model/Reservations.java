package fr.univlille.iut.gestionnaireplanning.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Entity
@Data
@NoArgsConstructor
public class Reservations {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;
    @Column(name = "uid")
    @JsonIgnore
    private String uid;
    @ManyToOne()
    @JoinColumn(name="user_id")
    private Users user;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="time_slot_id")
    @JsonIgnore
    private TimeSlots timeSlotId;
    @Column(name = "is_cancelled")
    @NotNull
    private boolean isCancelled = false;
    @Column(name = "cancel_reason")
    private String cancelReason;
    @Column(name = "nb_persons")
    @Min(1)
    private int nbPersons = 1;

    public Reservations(Users user, TimeSlots timeSlotId, int nbPersons) {
        this.user = user;
        this.timeSlotId = timeSlotId;
        this.isCancelled = false;
        this.cancelReason = null;
        this.nbPersons = nbPersons;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Reservations that = (Reservations) o;
        return id == that.id && isCancelled == that.isCancelled && nbPersons == that.nbPersons && Objects.equals(user, that.user) && Objects.equals(timeSlotId, that.timeSlotId) && Objects.equals(cancelReason, that.cancelReason);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, user, timeSlotId, isCancelled, cancelReason, nbPersons);
    }


}
