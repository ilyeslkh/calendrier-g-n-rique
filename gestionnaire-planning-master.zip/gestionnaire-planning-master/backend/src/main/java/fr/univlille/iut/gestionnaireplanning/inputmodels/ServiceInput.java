package fr.univlille.iut.gestionnaireplanning.inputmodels;

import lombok.Data;

import java.util.Arrays;

@Data
public class ServiceInput {
    private String name;
    private String logo;
    private int slotDuration;
    private int nbPersonMax;
    private PlanningDTO[] planning;

    @Override
    public String toString() {
        return "ServiceInput{" +
                "name='" + name + '\'' +
                ", logo='" + logo.substring(0, Math.min(logo.length(), 10)) + '\'' +
                ", slotDuration='" + slotDuration + '\'' +
                ", nbPersonMax='" + nbPersonMax + '\'' +
                ", planning=" + Arrays.toString(planning) +
                '}';
    }
}
