package fr.univlille.iut.gestionnaireplanning.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.sql.Date;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Users implements UserDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name = "last_name", nullable = false)
    @Size(min = 1, message = "Too short")
    private String lastName;
    @Column(name = "first_name", nullable = false)
    @Size(min = 1, message = "Too short")
    private String firstName;
    @Column(name = "email", unique = true, nullable = false)
    @Pattern(regexp = "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")
    private String email;
    @NotNull
    @Column(name = "password", nullable = false)
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String password;
    @Column(name = "phone_number", nullable = false, unique = true)
    @Pattern(regexp = "^(?:(?:\\+|00)33|0)\\s*[1-9](?:[\\s.-]*\\d{2}){4}$")
    @NotNull
    private String phoneNumber;
    @Lob
    @Column(name = "profile_picture")
    private byte[] profilePicture;
    @Column(name = "user_role")
    @Enumerated(EnumType.STRING)
    private Role userRole;

    @Column(name="enabled")
    private boolean enabled;

    @Override
    @JsonIgnore
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority(userRole.name()));
    }

    @Override
    public String getUsername() {
        return email;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Users users = (Users) o;
        return id == users.id && enabled == users.enabled && Objects.equals(lastName, users.lastName) && Objects.equals(firstName, users.firstName) && Objects.equals(email, users.email) && Objects.equals(password, users.password) && Objects.equals(phoneNumber, users.phoneNumber) && Arrays.equals(profilePicture, users.profilePicture) && userRole == users.userRole;
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(id, lastName, firstName, email, password, phoneNumber, userRole, enabled);
        result = 31 * result + Arrays.hashCode(profilePicture);
        return result;
    }
}
