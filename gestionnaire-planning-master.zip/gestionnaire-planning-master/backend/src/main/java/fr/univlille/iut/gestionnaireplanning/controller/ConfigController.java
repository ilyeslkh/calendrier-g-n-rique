package fr.univlille.iut.gestionnaireplanning.controller;

import fr.univlille.iut.gestionnaireplanning.inputmodels.PlanningDTO;
import fr.univlille.iut.gestionnaireplanning.inputmodels.ServiceInput;
import fr.univlille.iut.gestionnaireplanning.model.ServiceConfig;
import fr.univlille.iut.gestionnaireplanning.model.WeeklyTimeSlots;
import fr.univlille.iut.gestionnaireplanning.services.ConfigService;
import fr.univlille.iut.gestionnaireplanning.services.TimeSlotsService;
import fr.univlille.iut.gestionnaireplanning.services.WeeklyTimeSlotsService;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/config")
public class ConfigController {
    private final ConfigService configService;
    private final WeeklyTimeSlotsService wtsService;

    public ConfigController(ConfigService configService, WeeklyTimeSlotsService wtsService) {
        this.configService = configService;
        this.wtsService = wtsService;
    }

    @PostMapping()
    @Transactional
    public ServiceInput setConfig(@Valid @RequestBody ServiceInput input) {
        if (configService.serviceExists()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "La configuration existe déjà!");
        }

        ServiceConfig config = new ServiceConfig(input.getName(), input.getLogo().getBytes(StandardCharsets.UTF_8), input.getSlotDuration(), input.getNbPersonMax());
        configService.addService(config);
        List<WeeklyTimeSlots> wtsList = new ArrayList<>();
        for (PlanningDTO slot: input.getPlanning()) {
            LocalTime toAdd = slot.getStart();
            while (toAdd.plusMinutes(input.getSlotDuration()).isAfter(toAdd)
                    && TimeSlotsService.isBeforeOrEqual(toAdd.plusMinutes(input.getSlotDuration()), slot.getEnd())) {
                wtsList.add(new WeeklyTimeSlots(slot.getDay(), toAdd));
                toAdd = toAdd.plusMinutes(input.getSlotDuration());
            }
        }
        wtsService.addWeeklyTimeSlots(wtsList);
        return input;
    }

    @GetMapping()
    public ServiceConfig getConfig(){
        if (!configService.serviceExists()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "La configuration n'existe pas!");
        }
        return configService.getService();
    }
}
