package fr.univlille.iut.gestionnaireplanning.repositories;

import fr.univlille.iut.gestionnaireplanning.inputmodels.TimeSlotDateInput;
import fr.univlille.iut.gestionnaireplanning.inputmodels.TimeSlotInput;
import fr.univlille.iut.gestionnaireplanning.model.TimeSlots;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.sql.Date;
import java.time.LocalTime;
import java.util.List;

public interface TimeSlotsRepository extends CrudRepository<TimeSlots, Integer> {
    @Query(value =
            """
            /* Créneaux hebdomadaires sans réservations associées */
            select start_hour as startHour, false as isCancelled, 0 as nbPersons
            from weekly_time_slots
            where week_day = DAY_OF_WEEK(?1)
            and start_hour not in (select start_hour from time_slots where start_date = ?1)
            
            union
            
            select start_hour as startHour, ts.is_cancelled as isCancelled, case sum(r.nb_persons) when is null then 0 else sum(r.nb_persons) end as nbPersons
            from time_slots as ts left join (select * from reservations where is_cancelled is false) as r on(ts.id = r.time_slot_id)
            where start_date = ?1
            group by start_hour, ts.is_cancelled
            order by startHour;"""
            , nativeQuery = true)
    List<TimeSlotInput> findAllTimeSlotsOfTheDay(Date day);

    @Query(value =
            """
            select ts.start_date as startDate, case sum(r.nb_persons) when is null then 0 else sum(r.nb_persons) end as nbPersons,
            (select count(*) from time_slots ts2 where ts2.start_date = ts.start_date and ts2.is_cancelled = false) +
            (select count(*) from weekly_time_slots where week_day = DAY_OF_WEEK(ts.start_date) and start_hour not in (select start_hour from time_slots where start_date = ts.start_date)) as nbTimeSlots
            from time_slots as ts left join (select * from reservations where is_cancelled is false) as r on(ts.id = r.time_slot_id)
            where ts.start_date >= ?1 and ts.start_date <= ?2
            group by ts.start_date""", nativeQuery = true)
    List<TimeSlotDateInput> findAllTimeSlotsOfMonth(Date startDate, Date endDate);

    TimeSlots findTimeSlotsByStartDateAndStartHour(Date startDate, LocalTime startHour);
}
