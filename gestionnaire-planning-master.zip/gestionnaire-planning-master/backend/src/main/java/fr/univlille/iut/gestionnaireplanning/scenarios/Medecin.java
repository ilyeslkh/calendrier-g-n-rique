package fr.univlille.iut.gestionnaireplanning.scenarios;

import fr.univlille.iut.gestionnaireplanning.model.ServiceConfig;
import fr.univlille.iut.gestionnaireplanning.model.WeeklyTimeSlots;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;

public class Medecin implements Scenario {
    @Override
    public ServiceConfig getConfig() {
        return new ServiceConfig("Cabinet de M. Dupont", null, 15, 1);
    }

    @Override
    public Set<WeeklyTimeSlots> getWeeklyTimeSlots() {
        Set<WeeklyTimeSlots> result = new HashSet<>();
        for (int i = 1; i < 6; i++) {
            LocalTime time = LocalTime.of(8, 0);
            while (time.isBefore(LocalTime.of(17, 0))) {
                result.add(new WeeklyTimeSlots(i, time));
                if (time.getHour() == 12) {
                    time = time.plusMinutes(90);
                } else {
                    time = time.plusMinutes(15);
                }

            }
        }
        return result;
    }

    @Override
    public InputStream getImageStream() {
        return getClass().getClassLoader().getResourceAsStream("medecin.txt");
    }
}
