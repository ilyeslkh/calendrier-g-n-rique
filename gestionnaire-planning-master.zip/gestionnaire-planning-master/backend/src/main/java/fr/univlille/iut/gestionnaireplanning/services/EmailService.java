package fr.univlille.iut.gestionnaireplanning.services;

import fr.univlille.iut.gestionnaireplanning.config.FrontProperties;
import fr.univlille.iut.gestionnaireplanning.model.Reservations;
import fr.univlille.iut.gestionnaireplanning.model.TimeSlots;
import fr.univlille.iut.gestionnaireplanning.model.Users;
import jakarta.activation.DataHandler;
import jakarta.mail.BodyPart;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.Multipart;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;
import jakarta.mail.util.ByteArrayDataSource;
import net.fortuna.ical4j.model.*;
import net.fortuna.ical4j.model.component.VEvent;
import net.fortuna.ical4j.model.parameter.Cn;
import net.fortuna.ical4j.model.parameter.Role;
import net.fortuna.ical4j.model.property.*;
import net.fortuna.ical4j.util.RandomUidGenerator;
import net.fortuna.ical4j.util.UidGenerator;
import org.springframework.stereotype.Service;
import org.springframework.mail.javamail.JavaMailSender;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.SocketException;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

@Service
public class EmailService {
    private final JavaMailSender javaMailSender;
    private final ConfigService config;
    private final FrontProperties front;
    private final ReservationService reservationService;
    private final HTMLService html;
    private final UsersService usersService;

    public EmailService(JavaMailSender javaMailSender, ConfigService config, FrontProperties front, ReservationService reservationService, HTMLService html, UsersService usersService) {
        this.javaMailSender = javaMailSender;
        this.config = config;
        this.front = front;
        this.reservationService = reservationService;
        this.html = html;
        this.usersService = usersService;
    }

    public void sendFromReservation(Reservations reservation) {
        TimeSlots timeSlot = reservation.getTimeSlotId();
        sendCalendarInvite(reservation.getUser(), getStart(timeSlot), getEnd(timeSlot), reservation);
    }

    public void cancelFromReservation(Reservations reservation) {
        TimeSlots timeSlot = reservation.getTimeSlotId();
        cancelCalendarInvite(reservation.getUser(), getStart(timeSlot), getEnd(timeSlot), reservation);
    }

    private Instant getEnd(TimeSlots timeSlot) {
        LocalTime endHour = timeSlot.getStartHour().plusMinutes(config.getService().getSlotDuration());
        return endHour.atDate(timeSlot.getStartDate().toLocalDate()).
                atZone(ZoneId.systemDefault()).toInstant();
    }

    private static Instant getStart(TimeSlots timeSlot) {
        return timeSlot.getStartHour().atDate(timeSlot.getStartDate().toLocalDate()).
                atZone(ZoneId.systemDefault()).toInstant();
    }

    public void sendHTML(String to, String subject, String text) {
        try {
            MimeMessage message = javaMailSender.createMimeMessage();
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(to, "user"));
            message.setSubject(subject);
            message.setText(text);
            message.setContent(text, "text/html; charset=utf-8");
            javaMailSender.send(message);
        } catch (MessagingException | UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    public void sendCalendarInvite(Users user, Instant startDate, Instant endDate, Reservations res) {
        try {
            String buffer = getIcsCalendar(user, startDate, endDate, res).toString();
            String dateFormatted = new SimpleDateFormat("EEEE dd MMMM yyyy").format(res.getTimeSlotId().getStartDate());

            MimeMessage message = getMimeMessage(user, "Création d'un nouveau rendez-vous");
            String text = html.getHTMLTemplate(
                    "Réservation confirmée",
                    "Bonjour " + user.getFirstName() + " " + user.getLastName() + ", votre rendez-vous du " + dateFormatted + " a bien été enregistré.",
                    "Voir ma réservation",
                    getLink(res)
            );
            message.setContent(getMultipart(buffer, text));
            javaMailSender.send(message);
            message = getAdminMimeMessage("Création d'un nouveau rendez-vous");
            text = html.getHTMLTemplate(
                    "Nouvelle réservation",
                    "Bonjour, " + " un nouveau rendez-vous à la date du " + dateFormatted + " a été crée par " + user.getFirstName() + " " + user.getLastName() + ".",
                    "Voir la réservation",
                    getLink(res)
            );
            message.setContent(getMultipart(buffer, text));
            javaMailSender.send(message);
        } catch (MessagingException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    private MimeMessage getMimeMessage(Users user, String subject) throws MessagingException, UnsupportedEncodingException {
        MimeMessage message = javaMailSender.createMimeMessage();
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(user.getEmail(), "user"));
        message.addHeaderLine("method=REQUEST");
        message.addHeaderLine("charset=UTF-8");
        message.addHeaderLine("component=VEVENT");
        message.setSubject(subject);
        return message;
    }

    private MimeMessage getAdminMimeMessage(String subject) throws MessagingException {
        MimeMessage message = javaMailSender.createMimeMessage();
        InternetAddress[] addresses = usersService.getAllAdmins()
                .stream()
                .map(u -> {
                    try {
                        return new InternetAddress(u.getEmail(), "user");
                    } catch (UnsupportedEncodingException e) {
                        return null;
                    }
                }).toArray(InternetAddress[]::new);
        message.setRecipients(Message.RecipientType.TO, addresses);
        message.addHeaderLine("method=REQUEST");
        message.addHeaderLine("charset=UTF-8");
        message.addHeaderLine("component=VEVENT");
        message.setSubject(subject);
        return message;
    }

    private String getLink(Reservations res) {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        LocalTime startHour = res.getTimeSlotId().getStartHour();
        cal.setTime(res.getTimeSlotId().getStartDate());
        return front.getUrl()
                + "/slot?year=" + cal.get(java.util.Calendar.YEAR)
                + "&month=" + cal.get(java.util.Calendar.MONTH) + 1
                + "&day=" + cal.get(java.util.Calendar.DAY_OF_MONTH)
                + "&startHour=" + startHour.format(DateTimeFormatter.ofPattern("HH:mm"));
    }

    private Calendar getIcsCalendar(Users user, Instant startDate, Instant endDate, Reservations res) throws SocketException {
        UidGenerator ug = new RandomUidGenerator();
        Uid uid = ug.generateUid();
        VEvent meeting = new VEvent(startDate, endDate, "Rendez-vous " + config.getService().getName())
                .withProperty(uid)
                .withProperty(
                        new Attendee(URI.create("mailto:" + user.getEmail()))
                                .withParameter(Role.REQ_PARTICIPANT)
                                .withParameter(new Cn(user.getFirstName() + " " + user.getLastName()))
                                .getFluentTarget())
                .withProperty(new Link(front.getUrl()))
                .getFluentTarget();
        res.setUid(uid.getValue());
        reservationService.save(res);
        return new Calendar()
                .withProdId("-//Events Calendar//Time Minder//FR")
                .withDefaults()
                .withComponent(meeting)
                .getFluentTarget();
    }

    public void cancelCalendarInvite(Users user, Instant startDate, Instant endDate, Reservations res) {
        try {
            String buffer = getCancelCalendar(user, startDate, endDate, res).toString();
            String dateFormatted = new SimpleDateFormat("EEEE dd MMMM yyyy").format(res.getTimeSlotId().getStartDate());
            MimeMessage message = getMimeMessage(user, "Annulation d'un rendez-vous");
            String text = html.getHTMLTemplate(
                    "Réservation annulée",
                    "Bonjour " + user.getFirstName() + " " + user.getLastName() + ", votre rendez-vous du " + dateFormatted + " a été annulé.",
                    "Voir ma réservation",
                    getLink(res)
            );
            message.setContent(getMultipart(buffer, text));
            javaMailSender.send(message);
            message = getAdminMimeMessage("Annulation d'un rendez-vous");
            text = html.getHTMLTemplate(
                    "Réservation annulée",
                    "Bonjour, " + " un rendez-vous à la date du " + dateFormatted + " a été annulé.",
                    "Voir la réservation",
                    getLink(res)
            );
            message.setContent(getMultipart(buffer, text));
            javaMailSender.send(message);
        } catch (MessagingException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static Multipart getMultipart(String buffer, String description) throws MessagingException, IOException {
        BodyPart messageBodyPart = new MimeBodyPart();
        messageBodyPart.setHeader("Content-Class", "urn:content-  classes:calendarmessage");
        messageBodyPart.setHeader("Content-ID", "calendar_message");
        messageBodyPart.setDataHandler(new DataHandler(
                new ByteArrayDataSource(buffer, "text/calendar")));
        BodyPart body = new MimeBodyPart();
        body.setDataHandler(new DataHandler(
                new ByteArrayDataSource(description, "text/html")));
        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(messageBodyPart);
        multipart.addBodyPart(body);
        return multipart;
    }

    private Calendar getCancelCalendar(Users user, Instant startDate, Instant endDate, Reservations res) {
        VEvent meeting = new VEvent(startDate, endDate, "Rendez-vous " + config.getService().getName())
                .withProperty(new Uid(res.getUid()))
                .withProperty(
                        new Attendee(URI.create("mailto:" + user.getEmail()))
                                .withParameter(Role.REQ_PARTICIPANT)
                                .withParameter(new Cn(user.getFirstName() + " " + user.getLastName()))
                                .getFluentTarget())
                .withProperty(new Link(front.getUrl()))
                .withProperty(new Status("CANCELLED"))
                .getFluentTarget();
        return new Calendar()
                .withProdId("-//Events Calendar//Time Minder//FR")
                .withDefaults()
                .withComponent(meeting)
                .getFluentTarget();
    }
}
