package fr.univlille.iut.gestionnaireplanning.inputmodels;

import java.sql.Date;

public class DayAvgDTO {
    private Date date;
    private Double avg;

    public DayAvgDTO(Date date, Double avg) {
        this.date = date;
        this.avg = avg;
    }
}
