package fr.univlille.iut.gestionnaireplanning.services;

import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;

@Service
public class HTMLService {
    private final ConfigService config;

    public HTMLService(ConfigService config) {
        this.config = config;
    }

    public String getHTMLTemplate(String title, String description, String linkName, String link) {
        String logo = "";
        if (config.getService().getLogo() != null) {
            logo = new String(config.getService().getLogo(), StandardCharsets.UTF_8);
        }
        String name = config.getService().getName();
        return """
                <body>
                  <div id="container">
                    <header>
                      <h3>""" + name + "</h3>" + """
                      
                      <div id="logo"></div>
                    </header>
                    <div>
                      <h1>""" + title + "</h1>" + """
                      <p>""" + description + "</p>" + """
                      <a href=\"""" + link + "\" class='btn'>" + linkName + "</a>" + """
                    </div>
                    <footer>
                      <p>Ce mail a été envoyé automatiquement par l'application TimeMinder</p>
                    </footer>
                  </div>
                  <style>
                    body {
                      font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
                      background-color: rgb(243 244 246);
                    }
                                
                    * {
                      padding: 0;
                      margin: 0;
                    }
                                
                    #container {
                      background-color: white;
                      margin: auto;
                      height: 100vh;
                      min-height: 500px;
                      box-sizing: border-box;
                      max-width: 600px;
                      padding: 30px 40px;
                      display: flex;
                      flex-direction: column;
                      justify-content: space-between;
                      box-shadow: #eee 0px 1px 5px;
                    }
                    
                    header {
                          align-self: flex-end;
                          display: flex;
                          gap: 10px;
                          align-items: center
                    }
                                
                    #logo {
                      align-self: flex-end;
                      background-image: url(\"""" + logo + "\");" + """
                      box-shadow: #c1c1c1 0px 0px 3px;
                      background-size: cover;
                      background-position: center;
                      background-repeat: no-repeat;
                      border-radius: 0.25rem;
                      width: 3rem;
                      height: 3rem;
                    }
                                
                    h1 {
                      margin-bottom: 20px;
                    }
                                
                    .btn {
                      margin-top: 20px;
                      display: block;
                      color: white;
                      text-decoration: none;
                      background-color: rgb(239 68 68);
                      padding: 15px 30px;
                      border-radius: 10px;
                      font-weight: bold;
                      width: fit-content;
                    }
                                
                    footer {
                      color: rgb(136, 136, 136);
                      align-self: center;
                    }
                  </style>
                </body>
                """;
    }
}
