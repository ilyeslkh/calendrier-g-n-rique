package fr.univlille.iut.gestionnaireplanning.inputmodels;

import java.time.LocalTime;

public class PlanningDTO {
    private int day;
    private LocalTime start;
    private LocalTime end;

    public PlanningDTO(int day, LocalTime start, LocalTime end) {
        this.day = day;
        this.start = start;
        this.end = end;
    }

    public int getDay() {
        return day;
    }

    public LocalTime getStart() {
        return start;
    }

    public LocalTime getEnd() {
        return end;
    }

    @Override
    public String toString() {
        return "PlanningInput{" +
                "day=" + day +
                ", start=" + start +
                ", end=" + end +
                '}';
    }
}
