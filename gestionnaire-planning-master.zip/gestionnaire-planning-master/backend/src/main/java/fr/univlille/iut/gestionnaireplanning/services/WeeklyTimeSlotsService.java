package fr.univlille.iut.gestionnaireplanning.services;

import fr.univlille.iut.gestionnaireplanning.model.WeeklyTimeSlots;
import fr.univlille.iut.gestionnaireplanning.repositories.WeeklyTimeSlotsRepository;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class WeeklyTimeSlotsService {
    private final WeeklyTimeSlotsRepository wtsRepository;

    public WeeklyTimeSlotsService(WeeklyTimeSlotsRepository wtsRepository) {
        this.wtsRepository = wtsRepository;
    }

    public void addWeeklyTimeSlots(List<WeeklyTimeSlots> wts) {
        this.wtsRepository.saveAll(wts);
    }

    public WeeklyTimeSlots getWeeklyTimeSlot(Date date, LocalTime startHour) {
        int weekDay = date.toLocalDate().getDayOfWeek().ordinal()+1;
        return wtsRepository.findWeeklyTimeSlotsByWeekDayAndAndStartHour(weekDay, startHour);
    }

    public boolean[] listWeekDayHasWeeklyTimeSlots() {
        boolean[] list = new boolean[7];
        for (WeeklyTimeSlots weeklyTimeSlots : wtsRepository.findAll()) {
            list[weeklyTimeSlots.getWeekDay() - 1] = true;
        }
        return list;
    }
}
