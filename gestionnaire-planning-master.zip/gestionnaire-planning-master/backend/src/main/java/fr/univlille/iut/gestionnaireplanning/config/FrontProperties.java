package fr.univlille.iut.gestionnaireplanning.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("app.front")
@Data
public class FrontProperties {
    private String url;
}
