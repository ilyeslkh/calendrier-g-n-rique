package fr.univlille.iut.gestionnaireplanning.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Data
@NoArgsConstructor
@Table(name = "time_slots")
public class TimeSlots {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;
    @Column(name = "start_date")
    private Date startDate;
    @Column(name = "start_hour")
    private LocalTime startHour;
    @Column(name = "is_cancelled")
    @NotNull
    private boolean isCancelled = false;
    @Column(name = "cancel_reason")
    private String cancelReason;
    @OneToMany(mappedBy= "timeSlotId")
    private List<Reservations> reservations = new ArrayList<>();

    public TimeSlots(Date startDate, LocalTime startHour, boolean isCancelled, String cancelReason) {
        this.startDate = startDate;
        this.startHour = startHour;
        this.isCancelled = isCancelled;
        this.cancelReason = cancelReason;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TimeSlots timeSlots = (TimeSlots) o;
        return id == timeSlots.id && isCancelled == timeSlots.isCancelled && Objects.equals(startDate, timeSlots.startDate) && Objects.equals(startHour, timeSlots.startHour) && Objects.equals(cancelReason, timeSlots.cancelReason);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, startDate, startHour, isCancelled, cancelReason);
    }
}
