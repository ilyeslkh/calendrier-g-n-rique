package fr.univlille.iut.gestionnaireplanning.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Entity
@Data
@NoArgsConstructor
@Table(name = "service")
public class ServiceConfig {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;
    @Lob
    @Column(name = "logo")
    private byte[] logo;
    @Column(name = "name")
    @NotEmpty
    private String name;
    @Column(name = "slot_duration")
    private int slotDuration;
    @Column(name = "nb_person_max")
    @Min(1)
    private int nbPersonMax;

    public ServiceConfig(String name, byte[] logo, int slotDuration, int nbPersonMax) {
        this.name = name;
        this.logo = logo;
        this.slotDuration = slotDuration;
        this.nbPersonMax = nbPersonMax;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ServiceConfig serviceConfig = (ServiceConfig) o;
        return id == serviceConfig.id && slotDuration == serviceConfig.slotDuration && nbPersonMax == serviceConfig.nbPersonMax && Objects.equals(name, serviceConfig.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, slotDuration, nbPersonMax);
    }

}
