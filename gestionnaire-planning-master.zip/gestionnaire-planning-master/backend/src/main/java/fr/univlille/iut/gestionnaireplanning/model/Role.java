package fr.univlille.iut.gestionnaireplanning.model;

public enum Role {
    USER, ADMIN
}
