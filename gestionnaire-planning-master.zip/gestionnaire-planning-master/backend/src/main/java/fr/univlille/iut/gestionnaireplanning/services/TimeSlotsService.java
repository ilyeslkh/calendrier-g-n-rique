package fr.univlille.iut.gestionnaireplanning.services;

import fr.univlille.iut.gestionnaireplanning.inputmodels.*;
import fr.univlille.iut.gestionnaireplanning.inputmodels.custominfo.TimeSlotAdminInfo;
import fr.univlille.iut.gestionnaireplanning.inputmodels.custominfo.TimeSlotReservedInfo;
import fr.univlille.iut.gestionnaireplanning.model.*;
import fr.univlille.iut.gestionnaireplanning.repositories.ReservationRepository;
import fr.univlille.iut.gestionnaireplanning.repositories.TimeSlotsRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.TemporalField;
import java.time.temporal.TemporalUnit;
import java.util.Calendar;
import java.util.List;

@Service
public class TimeSlotsService {
    private final TimeSlotsRepository tsRepository;
    private final WeeklyTimeSlotsService wtsService;
    private final ReservationRepository rRepository;
    private final ConfigService configService;
    private final TokenService token;

    public TimeSlotsService(TimeSlotsRepository tsRepository, WeeklyTimeSlotsService wtsService, ReservationRepository rRepository, ConfigService configService, TokenService token) {
        this.tsRepository = tsRepository;
        this.wtsService = wtsService;
        this.rRepository = rRepository;
        this.configService = configService;
        this.token = token;
    }

    public Iterable<TimeSlotInput> getTimeSlotsOfDay(Date day) {
        return this.tsRepository.findAllTimeSlotsOfTheDay(day);
    }

    public TimeSlotOutput getTimeSlotOutput(TimeSlots timeSlot) {
        TimeSlotOutput ts = new TimeSlotOutput(timeSlot);
        if (!this.token.isConnected()) {
            return ts;
        }
        if (this.token.isAdmin() && !timeSlot.getReservations().isEmpty()) {
            ts.setResponseType(TimeSlotOutput.ResponseType.ADMIN);
            ts.setCustomInfo(new TimeSlotAdminInfo(timeSlot.getReservations()));
        } else {
            List<Reservations> userReservations = getReservationsOfUser(timeSlot);
            if (!userReservations.isEmpty()) {
                ts.setResponseType(TimeSlotOutput.ResponseType.RESERVED);
                ts.setCustomInfo(new TimeSlotReservedInfo(userReservations));
            }
        }
        return ts;
    }

    private List<Reservations> getReservationsOfUser(TimeSlots timeSlot) {
         return timeSlot
                .getReservations()
                .stream()
                .filter(r->r.getUser().getId() == token.getUserId())
                .toList();
    }

    public TimeSlots find(Date startDate, LocalTime startHour) {
        return tsRepository.findTimeSlotsByStartDateAndStartHour(startDate, startHour);
    }

    public TimeSlots createTimeSlot(Date date, LocalTime startHour) {
        if (hasDatePassed(date, startHour)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Le créneau est déjà passé!");
        }
        TimeSlots ts = new TimeSlots(date, startHour, false, null);
        return tsRepository.save(ts);
    }

    public boolean hasDatePassed(Date date, LocalTime startHour) {
        long dateTimestamp = Timestamp.valueOf(date.toLocalDate().atStartOfDay()).getTime();
        long hourTimeStamp = (long) startHour.getHour() * 3600000 + startHour.getMinute() * 60000 + startHour.getSecond() * 1000;
        date.setTime(dateTimestamp + hourTimeStamp);
        return date.before(new Date(System.currentTimeMillis()));
    }

    public boolean isTimeSlotCurrentlyBookedBy(TimeSlots timeSlot, int userId) {
        List<Reservations> reservations = rRepository.findAllByTimeSlotId(timeSlot);
        return reservations.stream().anyMatch((reservation ->
            reservation.getUser().getId() == userId && !reservation.isCancelled()
        ));
    }

    public int getNbPersons(TimeSlots existingTs) {
        return existingTs.getReservations()
                .stream()
                .filter(r -> !r.isCancelled())
                .mapToInt(Reservations::getNbPersons)
                .sum();
    }

    public TimeSlots createNewTimeSlot(ReservationsDTO reservationInfos) {
        WeeklyTimeSlots wts = wtsService.getWeeklyTimeSlot(reservationInfos.getDate(), reservationInfos.getStartHour());
        if (wts == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Le créneau n'existe pas!");
        }
        return createTimeSlot(reservationInfos.getDate(), wts.getStartHour());
    }

    public List<TimeSlotDateInput> getAvgNbPersonOfDayForMonth(Date start, Date end) {
        List<TimeSlotDateInput> result = tsRepository.findAllTimeSlotsOfMonth(start, end);
        boolean[] hasWeeklyTimeSlots = wtsService.listWeekDayHasWeeklyTimeSlots();
        LocalDate date = start.toLocalDate();
        while (date.isBefore(end.toLocalDate()) || date.equals(end.toLocalDate())) {
            LocalDate finalDate = date;
            boolean hasTimeSlots = result.stream().anyMatch((ts) -> ts.getStartDate().equals(finalDate));
            if (!hasTimeSlots && hasWeeklyTimeSlots[finalDate.getDayOfWeek().ordinal()]) {
                result.add(new TimeSlotDateInput() {
                    @Override
                    public LocalDate getStartDate() {
                        return finalDate;
                    }

                    @Override
                    public int getNbPersons() {
                        return 0;
                    }

                    @Override
                    public int getNbTimeSlots() {
                        return 1;
                    }
                });
            }
            date = date.plusDays(1);
        }
        return result;
    }

    public boolean canAddTimeSlot(TimeSlots ts) {
        int slotDuration = configService.getSlotDuration();
        List<TimeSlotInput> alreadyAdded = tsRepository.findAllTimeSlotsOfTheDay(ts.getStartDate());
        LocalTime tsEndHour = ts.getStartHour().plusMinutes(slotDuration);
        for (TimeSlotInput added: alreadyAdded) {
            LocalTime addedEndHour = added.getStartHour().plusMinutes(slotDuration);
            if ((addedEndHour.isAfter(ts.getStartHour()) && isBeforeOrEqual(added.getStartHour(),ts.getStartHour())) ||
                (addedEndHour.isAfter(tsEndHour) && added.getStartHour().isBefore(tsEndHour))) {
                return false;
            }
        }
        return true;
    }

    public static boolean isBeforeOrEqual(LocalTime a, LocalTime b) {
        return a.isBefore(b) || a.toNanoOfDay() == b.toNanoOfDay();
    }

    public Iterable<TimeSlots> addAllTimeSlots(List<TimeSlots> tsList) {
        return tsRepository.saveAll(tsList);
    }

    public void save(TimeSlots timeslot) {
        tsRepository.save(timeslot);
    }

    public TimeSlots findOrCreate(Date date, LocalTime startHour) {
        TimeSlots ts = find(date, startHour);
        if (ts != null) {
            return ts;
        }
        return createTimeSlot(date, startHour);
    }
}
