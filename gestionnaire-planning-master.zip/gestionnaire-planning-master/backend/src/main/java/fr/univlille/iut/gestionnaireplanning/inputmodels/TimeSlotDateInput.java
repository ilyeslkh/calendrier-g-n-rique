package fr.univlille.iut.gestionnaireplanning.inputmodels;

import java.time.LocalDate;

public interface TimeSlotDateInput {
    LocalDate getStartDate();
    int getNbPersons();
    int getNbTimeSlots();
}
