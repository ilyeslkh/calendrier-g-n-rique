package fr.univlille.iut.gestionnaireplanning;

import fr.univlille.iut.gestionnaireplanning.config.FrontProperties;
import fr.univlille.iut.gestionnaireplanning.config.RsaKeyProperties;
import fr.univlille.iut.gestionnaireplanning.config.ScenarioProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@EnableConfigurationProperties({RsaKeyProperties.class, FrontProperties.class, ScenarioProperties.class})
@SpringBootApplication
public class GestionnairePlanningApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionnairePlanningApplication.class, args);
	}

}
