package fr.univlille.iut.gestionnaireplanning.inputmodels.custominfo;

import fr.univlille.iut.gestionnaireplanning.model.Reservations;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class TimeSlotReservedInfo implements TimeSlotCustomInfo {
    private List<Reservations> reservations;
}
