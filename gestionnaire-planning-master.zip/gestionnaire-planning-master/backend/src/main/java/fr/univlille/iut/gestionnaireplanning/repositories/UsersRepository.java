package fr.univlille.iut.gestionnaireplanning.repositories;

import fr.univlille.iut.gestionnaireplanning.model.Role;
import fr.univlille.iut.gestionnaireplanning.model.Users;
import org.springframework.data.repository.CrudRepository;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.List;

public interface UsersRepository extends CrudRepository<Users, Integer>  {
    Users findByEmailAndPassword(String email, String password);

    Users findByEmail(String email);


    Users findByPhoneNumber(String phoneNumber);

    List<Users> findAllByUserRole(Role userRole);
}
