package fr.univlille.iut.gestionnaireplanning.errors;

public class UserNotFound extends Throwable {
    public UserNotFound(String message) {
        super(message);
    }
}
