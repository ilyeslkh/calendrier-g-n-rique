package fr.univlille.iut.gestionnaireplanning.inputmodels;

import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalTime;
import java.sql.Date;

@Data
@AllArgsConstructor
public class ReservationsDTO {
    @Min(1)
    private int nbPersons;
    private Date date;
    private LocalTime startHour;

}
