package fr.univlille.iut.gestionnaireplanning.controller;

import fr.univlille.iut.gestionnaireplanning.inputmodels.*;
import fr.univlille.iut.gestionnaireplanning.model.TimeSlots;
import fr.univlille.iut.gestionnaireplanning.services.*;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.sql.Date;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/timeslots")
public class TimeSlotController {

    private final TimeSlotsService tsService;
    private final WeeklyTimeSlotsService wtsService;
    private final ConfigService configService;
    private final TokenService token;

    public TimeSlotController(TimeSlotsService tsService, WeeklyTimeSlotsService wtsService, ConfigService configService, TokenService token) {
        this.tsService = tsService;
        this.wtsService = wtsService;
        this.configService = configService;
        this.token = token;
    }

    @GetMapping(path = "/{year}/{month}/{day}")
    public Iterable<TimeSlotInput> getAllTimeSlotOfDay(@PathVariable("year") int year, @PathVariable("month") int month, @PathVariable("day") int day) {
        try {
            return tsService.getTimeSlotsOfDay(Date.valueOf(year+"-"+month+"-"+day));
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Incorrect date format");
        }
    }

    @GetMapping(path = "/{year}/{month}/avgMonth")
    public List<TimeSlotDateInput> getAverageNbPersonOfDayForMonth(@PathVariable() int year, @PathVariable() int month) {
        try {
            Date start = Date.valueOf(year+"-"+month+"-01");
            Date end = Date.valueOf(start.toLocalDate().plusMonths(1).minusDays(1));
            return tsService.getAvgNbPersonOfDayForMonth(start, end);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Incorrect date format");
        }
    }

    @GetMapping(path = "/{year}/{month}/{day}/{startHour}")
    public TimeSlotOutput getTimeSlot(@PathVariable("year") int year, @PathVariable("month") int month, @PathVariable("day") int day, @PathVariable("startHour") LocalTime startHour) {
        Date date = Date.valueOf(year+"-"+month+"-"+day);
        TimeSlots timeSlot = tsService.find(date, startHour);
        if (timeSlot != null) {
            return tsService.getTimeSlotOutput(timeSlot);
        }
        if (wtsService.getWeeklyTimeSlot(date, startHour) == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Le créneau n'existe pas!");
        }
        return new TimeSlotOutput(null, date, startHour);
    }

    @PostMapping()
    public Iterable<TimeSlots> addSingleTimeSlot(@RequestBody() TimeSlotPostDTO timeSlot) {
        if (tsService.hasDatePassed(timeSlot.getStartDate(), timeSlot.getStartTime())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Vous ne pouvez pas créer un créneau dans le passé!");
        }

        int slotDuration = configService.getSlotDuration();
        List<TimeSlots> tsList = new ArrayList<>();
        LocalTime toAdd = timeSlot.getStartTime();
        while (toAdd.plusMinutes(slotDuration).isAfter(toAdd) && TimeSlotsService.isBeforeOrEqual(toAdd.plusMinutes(slotDuration), timeSlot.getEndTime())) {
            TimeSlots ts = new TimeSlots(timeSlot.getStartDate(), toAdd, false, null);
            if (tsService.canAddTimeSlot(ts)) {
                tsList.add(ts);
                toAdd = toAdd.plusMinutes(slotDuration);
            } else {
                throw new ResponseStatusException(HttpStatus.CONFLICT, "Un ou plusieurs créneaux existent déjà à ces horaires!");
            }
        }

        return tsService.addAllTimeSlots(tsList);
    }

    @PatchMapping(path = "/{year}/{month}/{day}/{startHour}")
    @Transactional
    public TimeSlotOutput patchTimeSlot(@PathVariable("year") int year, @PathVariable("month") int month, @PathVariable("day") int day, @PathVariable("startHour") LocalTime startHour, @Valid @RequestBody() TimeSlots toModify) {
        if (!token.isAdmin()) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Vous ne pouvez pas modifier un créneau!");
        }
        Date date = Date.valueOf(year+"-"+month+"-"+day);
        TimeSlots timeslot = tsService.findOrCreate(date, startHour);
        if (toModify.isCancelled()) {
            timeslot.setCancelled(true);
            if (toModify.getCancelReason() != null && !toModify.getCancelReason().isEmpty())
                timeslot.setCancelReason(toModify.getCancelReason());
            timeslot.getReservations().forEach(r -> r.setCancelled(true));
        }
        tsService.save(timeslot);
        return getTimeSlot(year, month, day, startHour);
    }
}
