package fr.univlille.iut.gestionnaireplanning.services;

import fr.univlille.iut.gestionnaireplanning.errors.UserNotFound;
import fr.univlille.iut.gestionnaireplanning.model.Role;
import fr.univlille.iut.gestionnaireplanning.model.Users;
import fr.univlille.iut.gestionnaireplanning.repositories.UsersRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@Service
public class UsersService implements UserDetailsService {
    private final UsersRepository usersRepository;
    private final TokenService token;

    public UsersService(UsersRepository usersRepository, TokenService token) {
        this.usersRepository = usersRepository;
        this.token = token;
    }

    public void saveUser(Users user) {
        usersRepository.save(user);
    }

    public Users getUserByEmailAndPassword(String email, String password) throws UserNotFound {
        Users user = usersRepository.findByEmailAndPassword(email, password);
        if(user == null){
            throw new UserNotFound("Invalid email and password");
        }
        return user;
    }

    public boolean emailAlreadyUsed(String email) {
        return usersRepository.findByEmail(email) != null;
    }

    public boolean phoneNumberAlreadyUsed(String phoneNumber) {
        return usersRepository.findByPhoneNumber(phoneNumber) != null;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        return usersRepository.findByEmail(email);
    }
    public Users getUserById(int userId) {
        Optional<Users> user=  usersRepository.findById(userId);
        if(user.isPresent()){
            return user.get();
        }
        throw new ResponseStatusException(HttpStatus.NOT_FOUND);

    }
    public Users putUser(Users user){
        Users userWithSameEmail = usersRepository.findByEmail(user.getEmail());
        if (userWithSameEmail != null && userWithSameEmail.getId() != token.getUserId()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already used!");
        }
        Users userWithSamePhoneNumber = usersRepository.findByPhoneNumber(user.getPhoneNumber());
        if (userWithSamePhoneNumber != null && userWithSamePhoneNumber.getId() != token.getUserId()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Phone number already used!");
        }
        Users current =  getUserById(token.getUserId());
        current.setEmail(user.getEmail());
        current.setFirstName(user.getFirstName());
        current.setLastName(user.getLastName());
        current.setPhoneNumber(user.getPhoneNumber());
        current.setProfilePicture(user.getProfilePicture());
        return usersRepository.save(current);
    }

    public void checkUserChangeConflict(Users user) {
        if (emailAlreadyUsed(user.getEmail())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already used!");
        }
        if (phoneNumberAlreadyUsed(user.getPhoneNumber())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Phone number already used!");
        }
    }

    public void checkPasswordInput(String password) {
        Users existingUser = this.getUserById(token.getUserId());
        PasswordEncoder passwordEncoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
        if (!passwordEncoder.matches(password, existingUser.getPassword())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Mauvais mot de passe");
        }
    }

    public List<Users> getAllAdmins() {
        return usersRepository.findAllByUserRole(Role.ADMIN);
    }
}
