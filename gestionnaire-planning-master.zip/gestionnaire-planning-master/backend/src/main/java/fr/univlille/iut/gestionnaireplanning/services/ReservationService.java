package fr.univlille.iut.gestionnaireplanning.services;

import fr.univlille.iut.gestionnaireplanning.inputmodels.UserReservationsDTO;
import fr.univlille.iut.gestionnaireplanning.model.Reservations;
import fr.univlille.iut.gestionnaireplanning.model.TimeSlots;
import fr.univlille.iut.gestionnaireplanning.model.Users;
import fr.univlille.iut.gestionnaireplanning.repositories.ReservationRepository;
import fr.univlille.iut.gestionnaireplanning.repositories.UsersRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static fr.univlille.iut.gestionnaireplanning.model.Role.ADMIN;

@Service
public class ReservationService {
    private final ReservationRepository reservationRepository;
    private final UsersRepository usersRepository;
    private final ConfigService config;
    private final TimeSlotsService tsService;

    public ReservationService(ReservationRepository reservationRepository, UsersRepository usersRepository, ConfigService config, TimeSlotsService tsService) {
        this.reservationRepository = reservationRepository;
        this.usersRepository = usersRepository;
        this.config = config;
        this.tsService = tsService;
    }


    public Reservations createReservation(TimeSlots timeSlot, int nbPersons, int userId) {
        if (tsService.getNbPersons(timeSlot) + nbPersons > config.getService().getNbPersonMax()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Trop de personnes pour ce créneau");
        }
        if (tsService.isTimeSlotCurrentlyBookedBy(timeSlot, userId)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Il y a déjà une réservation pour cet utilisateur!");
        }
        if (nbPersons < 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La réservation doit inclure au moins 1 personne!");
        }
        Users user = usersRepository.findById(userId).orElse(null);
        Reservations reservation = new Reservations(user, timeSlot, nbPersons);
        return reservationRepository.save(reservation);
    }

    public List<UserReservationsDTO> getCurrentReservationByUser(Users user) {
        if (user.getUserRole() == ADMIN) {
            return reservationRepository.findCurrentReservationsAdmin(new Date(), LocalTime.now());
        } else {
            return reservationRepository.findCurrentReservationsOfUser(user.getId(), new Date(), LocalTime.now());
        }
    }

    public List<UserReservationsDTO> getPastReservationByUser(Users user) {
        if (user.getUserRole() == ADMIN) {
            return reservationRepository.findPastReservationsAdmin(new Date(), LocalTime.now());
        } else {
            return reservationRepository.findPastReservationsOfUser(user.getId(), new Date(), LocalTime.now());
        }
    }

    public Reservations findById(int id) {
        Optional<Reservations> reservations = reservationRepository.findById(id);
        if (reservations.isPresent()) {
            return reservations.get();
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
    }

    public void save(Reservations reservation) {
        reservationRepository.save(reservation);
    }
}
