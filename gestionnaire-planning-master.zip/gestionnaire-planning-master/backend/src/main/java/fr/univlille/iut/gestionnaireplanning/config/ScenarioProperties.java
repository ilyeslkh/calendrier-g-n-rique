package fr.univlille.iut.gestionnaireplanning.config;

import fr.univlille.iut.gestionnaireplanning.scenarios.ScenarioType;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("app.scenario")
@Data
public class ScenarioProperties {
    @Enumerated(EnumType.STRING)
    private ScenarioType name;
}
