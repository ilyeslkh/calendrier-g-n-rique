package fr.univlille.iut.gestionnaireplanning.repositories;

import fr.univlille.iut.gestionnaireplanning.model.WeeklyTimeSlots;
import org.springframework.data.repository.CrudRepository;

import java.time.LocalTime;

public interface WeeklyTimeSlotsRepository extends CrudRepository<WeeklyTimeSlots, Integer> {
    WeeklyTimeSlots findWeeklyTimeSlotsByWeekDayAndAndStartHour(int weekDay, LocalTime startHour);
}
