package fr.univlille.iut.gestionnaireplanning.scenarios;

import java.util.function.Supplier;

public enum ScenarioType {
    PISCINE(Piscine::new),
    MEDECIN(Medecin::new);

    private final Supplier<Scenario> supplier;

    ScenarioType(Supplier<Scenario> supplier) {
        this.supplier = supplier;
    }

    public Supplier<Scenario> getSupplier() {
        return supplier;
    }
}
