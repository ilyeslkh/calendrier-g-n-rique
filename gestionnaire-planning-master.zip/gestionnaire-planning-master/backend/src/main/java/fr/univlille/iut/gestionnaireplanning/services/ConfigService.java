package fr.univlille.iut.gestionnaireplanning.services;

import fr.univlille.iut.gestionnaireplanning.model.ServiceConfig;
import fr.univlille.iut.gestionnaireplanning.repositories.ConfigRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ConfigService {
    private final ConfigRepository configRepository;

    public ConfigService(ConfigRepository configRepository) {
        this.configRepository = configRepository;
    }

    public ServiceConfig getService() {
        if (configRepository.count() == 0) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Le service n'existe pas");
        return configRepository.findAll().iterator().next();
    }

    public boolean serviceExists() {
        return configRepository.count() > 0;
    }

    public void addService(ServiceConfig config) {
        configRepository.save(config);
    }

    public int getSlotDuration() {
        return getService().getSlotDuration();
    }
}
