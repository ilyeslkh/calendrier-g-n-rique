package fr.univlille.iut.gestionnaireplanning.inputmodels;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.sql.Date;
import java.time.LocalTime;
@Data
@AllArgsConstructor
public class UserReservationsDTO {
    private Date date;
    private LocalTime startHour;
    private Number nbPersons;
    private boolean cancelled;
}
