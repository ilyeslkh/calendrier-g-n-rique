package fr.univlille.iut.gestionnaireplanning.controller;

import fr.univlille.iut.gestionnaireplanning.config.FrontProperties;
import fr.univlille.iut.gestionnaireplanning.model.PasswordInput;
import fr.univlille.iut.gestionnaireplanning.model.Role;
import fr.univlille.iut.gestionnaireplanning.model.Users;
import fr.univlille.iut.gestionnaireplanning.services.*;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.nio.charset.StandardCharsets;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/users")
public class UsersController {

    private final TokenService tokenService;
    private final UsersService usersService;
    private final EmailService emailService;
    private final PasswordEncoder encoder;
    private final FrontProperties front;
    private final HTMLService html;

    public UsersController(TokenService tokenService, UsersService usersService, EmailService emailService, PasswordEncoder encoder, FrontProperties front, HTMLService html) {
        this.tokenService = tokenService;
        this.usersService = usersService;
        this.emailService = emailService;
        this.encoder = encoder;
        this.front = front;
        this.html = html;
    }

    @PostMapping("/token")
    public String loginUser(@Valid @NotNull Authentication authentication) {
        return tokenService.generateToken(authentication);
    }

    @GetMapping()
    public Users getUserById() {
        return usersService.getUserById(tokenService.getUserId());
    }

    @PutMapping()
    public Users putUser(@Valid @RequestBody Users user) {
        usersService.checkPasswordInput(user.getPassword());
        return usersService.putUser(user);
    }

    @PatchMapping("/password")
    public Users changePassword(@Valid @RequestBody PasswordInput passwords) {
        usersService.checkPasswordInput(passwords.getOldPassword());
        Users existingUser = usersService.getUserById(tokenService.getUserId());
        existingUser.setPassword(encoder.encode(passwords.getNewPassword()));
        usersService.saveUser(existingUser);
        return existingUser;
    }

    @PostMapping()
    public Users register(@Valid @RequestBody Users user){
        usersService.checkUserChangeConflict(user);

        user.setPassword(encoder.encode(user.getPassword()));
        user.setUserRole(Role.USER);
        usersService.saveUser(user);
        // Send confirmation email
        sendConfirmationEmail(user);
        return user;
    }

    private void sendConfirmationEmail(Users user) {
        String subject = "Confirmation du compte";
        String confirmationLink = front.getUrl() + "/confirmation?token=" + tokenService.generateConfirmationToken(user);
        String text = html.getHTMLTemplate(
            "Confirmer mon inscription",
            "Bienvenue sur TimeMinder!<br/>Veuillez confirmer votre adresse e-mail en cliquant sur le bouton ci-dessous.",
            "Confirmer mon adresse e-mail",
            confirmationLink
        );
        emailService.sendHTML(user.getEmail(), subject, text);
    }

    @PostMapping("/confirm")
    public Users confirm(){
        Users user = usersService.getUserById(tokenService.getUserId());
        if (user.isEnabled()) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        }
        user.setEnabled(true);
        usersService.saveUser(user);
        return user;
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ProblemDetail details(ConstraintViolationException erreur) {
        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, erreur.getMessage());
    }
}

