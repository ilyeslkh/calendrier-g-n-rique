package fr.univlille.iut.gestionnaireplanning.repositories;

import fr.univlille.iut.gestionnaireplanning.model.ServiceConfig;
import org.springframework.data.repository.CrudRepository;

public interface ConfigRepository extends CrudRepository<ServiceConfig, Integer> {
}
