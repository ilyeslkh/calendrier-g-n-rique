package fr.univlille.iut.gestionnaireplanning.repositories;

import fr.univlille.iut.gestionnaireplanning.inputmodels.UserReservationsDTO;
import fr.univlille.iut.gestionnaireplanning.model.Reservations;
import fr.univlille.iut.gestionnaireplanning.model.TimeSlots;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.time.LocalTime;
import java.util.Date;
import java.util.List;

public interface ReservationRepository extends CrudRepository<Reservations, Integer>  {
    List<Reservations> findAllByTimeSlotId(TimeSlots ts);

    @Query(value = """
    select new fr.univlille.iut.gestionnaireplanning.inputmodels.UserReservationsDTO(r.timeSlotId.startDate, r.timeSlotId.startHour, r.nbPersons, r.isCancelled or r.timeSlotId.isCancelled)
    from Reservations r
    where r.user.id = ?1
    and (r.timeSlotId.startDate > ?2
    or (r.timeSlotId.startDate = ?2 and r.timeSlotId.startHour > ?3))
    """)
    List<UserReservationsDTO> findCurrentReservationsOfUser(int userId, Date currentDate, LocalTime currentHour);

    @Query(value = """
    select new fr.univlille.iut.gestionnaireplanning.inputmodels.UserReservationsDTO(r.timeSlotId.startDate, r.timeSlotId.startHour, r.nbPersons, r.isCancelled or r.timeSlotId.isCancelled)
    from Reservations r
    where r.user.id = ?1
    and (r.timeSlotId.startDate < ?2
    or (r.timeSlotId.startDate = ?2 and r.timeSlotId.startHour <= ?3))
    """)
    List<UserReservationsDTO> findPastReservationsOfUser(int userId, Date currentDate, LocalTime currentHour);


    @Query(value = """
    select new fr.univlille.iut.gestionnaireplanning.inputmodels.UserReservationsDTO(r.timeSlotId.startDate, r.timeSlotId.startHour, sum(r.nbPersons), r.timeSlotId.isCancelled)
    from Reservations r
    where r.isCancelled = false
    and r.timeSlotId.startDate > ?1
    or (r.timeSlotId.startDate = ?1 and r.timeSlotId.startHour > ?2)
    group by r.timeSlotId.startDate, r.timeSlotId.startHour, r.timeSlotId.isCancelled
    """)
    List<UserReservationsDTO> findCurrentReservationsAdmin(Date currentDate, LocalTime currentHour);

    @Query(value = """
    select new fr.univlille.iut.gestionnaireplanning.inputmodels.UserReservationsDTO(r.timeSlotId.startDate, r.timeSlotId.startHour, sum(r.nbPersons), r.timeSlotId.isCancelled)
    from Reservations r
    where r.isCancelled = false
    and r.timeSlotId.startDate < ?1
    or (r.timeSlotId.startDate = ?1 and r.timeSlotId.startHour <= ?2)
    group by r.timeSlotId.startDate, r.timeSlotId.startHour, r.timeSlotId.isCancelled
    """)
    List<UserReservationsDTO> findPastReservationsAdmin(Date currentDate, LocalTime currentHour);
}
