package fr.univlille.iut.gestionnaireplanning.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalTime;
import java.util.Objects;

@Entity
@Data
@NoArgsConstructor
@Table(name = "weekly_time_slots")
public class WeeklyTimeSlots {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private int id;
    @Column(name = "week_day")
    @Min(1)
    @Max(7)
    private int weekDay;
    @Column(name = "start_hour")
    private LocalTime startHour;

    public WeeklyTimeSlots(int weekDay, LocalTime startHour) {
        this.weekDay = weekDay;
        this.startHour = startHour;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WeeklyTimeSlots that = (WeeklyTimeSlots) o;
        return id == that.id && weekDay == that.weekDay && Objects.equals(startHour, that.startHour);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, weekDay, startHour);
    }
}
