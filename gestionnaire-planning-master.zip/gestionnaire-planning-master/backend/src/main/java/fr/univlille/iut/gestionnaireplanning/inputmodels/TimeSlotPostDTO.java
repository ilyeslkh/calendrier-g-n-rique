package fr.univlille.iut.gestionnaireplanning.inputmodels;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.sql.Date;
import java.time.LocalTime;

@Data
public class TimeSlotPostDTO {
    @NotNull()
    Date startDate;
    @NotNull()
    LocalTime startTime;
    @NotNull()
    LocalTime endTime;
}
