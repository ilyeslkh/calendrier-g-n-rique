package fr.univlille.iut.gestionnaireplanning;

import fr.univlille.iut.gestionnaireplanning.config.ScenarioProperties;
import fr.univlille.iut.gestionnaireplanning.model.*;
import fr.univlille.iut.gestionnaireplanning.repositories.*;
import fr.univlille.iut.gestionnaireplanning.scenarios.Scenario;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.Date;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class DbInit implements ApplicationRunner {
    private final ConfigRepository configRepository;
    private final WeeklyTimeSlotsRepository wtsRepository;
    private final UsersRepository usersRepository;
    private final ReservationRepository reservationRepository;
    private final ScenarioProperties scenarioProperties;
    private final LocalDate DATE_START =  LocalDate.of(2023, 6, 15);
    private final LocalDate DATE_END =  LocalDate.of(2024, 10, 15);

    public DbInit(ConfigRepository configRepository, WeeklyTimeSlotsRepository wtsRepository, UsersRepository usersRepository, ReservationRepository reservationRepository, ScenarioProperties scenarioProperties) {
        this.configRepository = configRepository;
        this.wtsRepository = wtsRepository;
        this.usersRepository = usersRepository;
        this.reservationRepository = reservationRepository;
        this.scenarioProperties = scenarioProperties;
    }

    @Override
    public void run(ApplicationArguments args) throws IOException {
        if (scenarioProperties.getName() != null) {
            runScenario(scenarioProperties.getName().getSupplier().get());
        }
    }

    private void runScenario(Scenario scenario) throws IOException {
        ServiceConfig config = createConfig(scenario);
        Set<WeeklyTimeSlots> weeklyTimeSlots = scenario.getWeeklyTimeSlots();
        wtsRepository.saveAll(weeklyTimeSlots);
        System.out.println("Récupération des utilisateurs, le hashage des mots de passe prend du temps...");
        List<Users> users = getUsers();
        usersRepository.saveAll(users);
        Map<Integer, Set<WeeklyTimeSlots>> wtsMap = groupByDayOfWeek(weeklyTimeSlots);
        addReservations(wtsMap, users, config);
    }

    private void addReservations(Map<Integer, Set<WeeklyTimeSlots>> wtsMap, List<Users> users, ServiceConfig config) {
        Set<Reservations> reservations = new HashSet<>();
        LocalDate date = LocalDate.from(DATE_START);
        Random rand = new Random();
        while (date.isBefore(DATE_END)) {
            double dayProba = rand.nextDouble() * 2;
            for (WeeklyTimeSlots wts: wtsMap.getOrDefault(date.getDayOfWeek().ordinal() + 1, new HashSet<>())) {
                if (rand.nextDouble() > dayProba) {
                    addReservation(users, wts, date, reservations, config, dayProba);
                }
            }
            date = date.plusDays(1);
        }
        reservationRepository.saveAll(reservations);
    }

    private static void addReservation(List<Users> users, WeeklyTimeSlots wts, LocalDate date, Set<Reservations> reservations, ServiceConfig config, double dayProba) {
        Random rand = new Random();
        boolean cancelled = rand.nextDouble() > 0.90;
        TimeSlots ts = new TimeSlots(Date.valueOf(date), wts.getStartHour(), cancelled, null);
        Collections.shuffle(users);
        int nbToAdd = (int) Math.ceil(rand.nextDouble(config.getNbPersonMax() / 3.0) * 3.0);
        for (int i = 0; i < nbToAdd; i++) {
            Reservations r = new Reservations(users.get(i), ts, 1);
            r.setCancelled(cancelled || rand.nextDouble() > 0.90);
            reservations.add(r);
        }
    }

    private ServiceConfig createConfig(Scenario scenario) {
        ServiceConfig toSave = scenario.getConfig();
        String text = new BufferedReader(
                new InputStreamReader(scenario.getImageStream(), StandardCharsets.UTF_8))
                .lines()
                .collect(Collectors.joining("\n"));
        toSave.setLogo(text.getBytes(StandardCharsets.UTF_8));
        return configRepository.save(toSave);
    }

    private Map<Integer, Set<WeeklyTimeSlots>> groupByDayOfWeek(Set<WeeklyTimeSlots> weeklyTimeSlots) {
        Map<Integer, Set<WeeklyTimeSlots>> res = new HashMap<>();
        for (WeeklyTimeSlots wts: weeklyTimeSlots) {
            if (!res.containsKey(wts.getWeekDay())) {
                res.put(wts.getWeekDay(), new HashSet<>());
            }
            res.get(wts.getWeekDay()).add(wts);
        }
        return res;
    }

    private List<Users> getUsers() throws IOException {
        List<Users> users = new ArrayList<>();
        InputStream stream = getClass().getClassLoader().getResourceAsStream("MOCK_CLIENTS.csv");
        if (stream == null) {
            throw new RuntimeException("Fichier d'utilisateurs introuvable");
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        reader.readLine();
        String line;
        while ((line = reader.readLine()) != null) {
            String[] params = line.split(",");
            String password = PasswordEncoderFactories.createDelegatingPasswordEncoder().encode(params[4]);
            users.add(new Users(Integer.parseInt(params[0]),
                    params[1], params[2], params[3], password,
                    params[5], null, Role.valueOf(params[6]), true));
        }
        return users;
    }
}
