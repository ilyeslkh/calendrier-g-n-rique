package fr.univlille.iut.gestionnaireplanning.inputmodels;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AuthentificationDTO {
    private String email;
    private String password;
}
