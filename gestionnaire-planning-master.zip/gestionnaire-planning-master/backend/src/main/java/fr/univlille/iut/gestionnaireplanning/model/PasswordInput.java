package fr.univlille.iut.gestionnaireplanning.model;

import lombok.Data;

@Data
public class PasswordInput {
    private String oldPassword;
    private String newPassword;
}
