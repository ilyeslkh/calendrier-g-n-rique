package fr.univlille.iut.gestionnaireplanning.scenarios;

import fr.univlille.iut.gestionnaireplanning.model.ServiceConfig;
import fr.univlille.iut.gestionnaireplanning.model.WeeklyTimeSlots;

import java.io.*;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.Set;

public class Piscine implements Scenario {
    @Override
    public ServiceConfig getConfig() {
        return new ServiceConfig("Piscine", null, 60, 100);
    }

    @Override
    public Set<WeeklyTimeSlots> getWeeklyTimeSlots() {
        Set<WeeklyTimeSlots> result = new HashSet<>();
        for (int i = 1; i < 6; i++) {
            LocalTime time = LocalTime.of(8, 0);
            while (time.isBefore(LocalTime.of(17, 0))) {
                result.add(new WeeklyTimeSlots(i, time));
                time = time.plusHours(1);
            }
        }
        return result;
    }

    @Override
    public InputStream getImageStream() {
        return getClass().getClassLoader().getResourceAsStream("piscine.txt");
    }
}
