INSERT INTO service(name, slot_duration, nb_person_max, logo) VALUES ('Cabinet de M. Dupont', 15, 1, 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADRCAYAAACJgf3NAAAAAXNSR0IB2cksfwAAAAlwSFlzAAALEwAACxMBAJqcGAAAGS1JREFUeJztnQl4G9W1x0kC2djCXiCQ2AkB68qJNZIl2bETCGELOyk7PJby2Mr6gAeFpvBYHntZCoVSWihrWQtleawttFDWhESSQ2LL9jhJC2EpO0kgRO9/dMdgy7I0kkYa2fr/vu//0S+1ZubeOWfuds69a61FCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEkP5pmTZuSKy5alPIgGZC+0E7QbXQRm4/HyGuAQeYCF0BvQV9DH0NrYa+gj6A/g6d09Jcta3bz0pIyYDRV0G/h1ZCCRv6QhwJjrKp289OSFGBoe8Lddl0jJ5aA0Uhn9tlIKQowLhnQ5/n4Rw99S/I73ZZCHEUdI8mWMZdiHN0a360uWoLt8tEiCPEmqpGwqifd8g5unWz2+UixBFgzLtA3zrsIHI9j9tlI6QgWhqqhhah9ejWDdGm6iFul5GQvIERb+XAwLw/RaD13S4jqXDMeKTKjEdPgy4z26MNZntsbbu/jU6rnlUk5xDJ+sg42+Voj26DMvwXdCE0o7O1ZVh+NULIWuIY0WboaWgFlLC0Bnob2qerrWVotmvAgE8pooN8B9XaKMc46B7oqx7lEMWgM/ABsO3whOBLG1kbhnMq9GGKQfXUv6Gjsl0LBnxJER0k0dJctWPGsmjn+EeGcnwL3Y8yj3WsAsngBcYyAroaWpXBqLr1qdkWnZnpejDi84vpIFCo37K0RUfjGd+wUQ5pFRdA4x2vUDJ4MOMxcY4roNU2jKpbYlj9LtrBgI8ponN8A01KX5boMOjSHMohmivjlOLVMBmwwDjWg+6yvqa5GJXohSWtkbTjERjwDjHn10C6tQzauJ/yHAh9k0dZlkE+OAqnj4mmMx7ZEEbxSB7G1LOLMjvdtVuaxq8DI15YJAd5IDqtus9MVFdbbAyeZ2kB5VkC7VL8midlDwxhB+jvBRhTtzqgienuAUM+LqajcZ10Drnebqn36oxHh+I57nCgPMuhw4v/BkjZIgYNvZ5ntypV30G/SncfGPIWUKfDDvJOFK1TmjLJ1PRHDpRHJDN1B6G7xfWSSgMvfhr0mkOG1K3PxEBT7xVrGi9ptfvH7CdIZZNkGzb1LVNkFO7/qkMO37MlOctsiw4vzZshrmLq2Z3dzML66Jn0FtRnZmnBrluIk1wKrSrQOT6D/nPhtN4xWHCOdXHfOUUqk0x5/w+chGEtgx286Nlm5gXAQiVfb1l93yz13jBsCXu/NaZXwPNxDmmBzog2V/WaMetsj8m442To6yKWSxYUb13SsaBPt44MAvByR0Jnm7mtcRSiqBmP7bAkHuv1pY80bSstyZHQ0hydow3aNTptXErLEZOW4zozvyndfPREVzy6eWnfHikq8jWXF1tCI+qWDJZvgH7U83lg6BICXwO12nSO+6BNYk1V3zvHkrbYOujyHI5rt5h6gqBUZZIWshXaseQvkjgPXqSC3imxY6TqE+h56BhTTyuPb/vtVZMX7hec37K3f1UWrVx4yPRb8Jttoe2gmdBtUHuJHSNV0k09uquDC4oDkq6uyBBTz1Qtc9k5UiWt2JdmW+RTc+HbX5stb63KopXmonlf4jefm3qw7OQMVaGS5zq3M97CcclAAi9tc1PHVK0oscFUoqQVk0kJr9vvndjA1K3GojIwnEqTdLmOM1sjXC8pR/ByNoDOM0s3S0Wl128hbpVaLnR0xGSs4TP1LJWbg1ZKqzu3ZH+GqLiMqVfFT4HeKwPDoHpL0ntvMNsjo922k4oDXyaJOTrQ+lKV06wO1Vdd0LlQ2rwV4iDL3n1XulN7Qc9BX5TBy6fsSaan50InLmmLcoMIpzHbknniu0APmsWNN6KKK4nn+ht0KHoB67ltVwMeVOToTu0Yj5v2NlGgBoZkpvEl6BA4yhi37WxAYcZjoyGPqRf6/lkGL5Mqrj41dehMENpwaecChq6k0tmWnI2SGKUTTJ3+ym5U5UlCcKKm3vmxDmOVygxf6ZQo1Hh0KygAHQv90eQ0LdVXEuclISwyjR+CtjTjg3Sr1K72liG6gNH/hh6D2kwdfOf2S6AGhsRZFkMPoPstIf6DZ23FbI9Ii/ETKGIyDIQqXNL9fgbqd0fJAYWpB1/Ly6BiqcEl2XCjT1rzgAOF2NNky0EVRwP/xN/Otugmpm4S3a5ManDpdTMeGRzhKyjMJOiFMqhUanBItkZtcNuuHQUtiQQYyhz3x2VQwdTAlKyVyId2cOabdMWTeeI10O0mp3kp+5Ix7F+gvbrisRFu23FJMOMxyQA8GLre1MlOr0DzTL0z4ctmcs47+qjJJKjBLklZuAP6k/Xe51r/fcrUH9LjYCvbuW2vZcmStshwUw7O1Hveuv0iKWclrcKL5mDtLpWKzrbkKny9qb8w7+fxIiRhR44hW5nnixzMO6NIhHQ+LbQkqcnGGPPN3Dfjk4W+N8326AnQSLfta9CAvqccrNkI/SZZwXpr/nTZhGLQsjG1JFVdDu3Q1R6R06NkgiBq0yDkurJLx/3QkaYOj0k9ITab3jdLE6K/Jo97SR3ICbenm7qFfjcHQ5dFX4m+lU3sNu2KR08ydTydOMznGd6JhBdJl/loiCHuxaI9Ph8tSkROUJoM7W295J+bOs5LjLkJqupsi43q+Tv0Y7vjweQFSS5CuhZFEnpkhfZMU+/ImIwo7dTHs+1pOV22FF/5QooTe03JdyjeLvKirywD397UkdDtNn4jLeo50NgutM4dHQu660UyNR829S6Q6ZxQDPwKq156ZQVa0dhyDT90gKnPlP+FdZ9DTf1hG9sZr9AI3YGI2Z5skbYx9RqNaFxnPPueTqbeAlScRTbCln13fw3dZCbPG4/uIce59f77iGyaPcv6u0Upjrm6851Xv+h49uGv2+668aPWq85dsXjOSV8uvuiUla3XzVnR/sxDX5iL3knt4sl4TBLIjulMCbVY1rZAdnmX7qjEvl0J3WI92yWWofo6OjKf7b6sI5nWLBvvbWfVy4TOeIzZfyQ3TGnJ2qLrdLZHZSJhuGnOz5jok/ybeHQLU+e9BNqfuHfnd4+Y+W7LPoFVLbuq72I7bbc6Nq36h2Papk9Yg39fvfDApm8WXXD8Q/jNPtAMbbSRdeOLMycWyVdeDr1BywlFBmeYOBm8tDRXbQZHWGBzd/fr3X5eQkoKHYQMWjxGcKjyh4Z5jNDaXl9oHWWEhkMjlC9ke0sbJx0Ez7A27j3CayQlz7KO0s+1thfPqYzw0FpfM3O9Se54feGRMKStIAXVQztCe0EHQcdAJ0KnQedAF0CXQFdDN0G3Q3dDf4QehX4H/Qw6EgoqI9jv4NYJB8E9JkFnWPd93HqGB6H7oLug30O3QL+ELoN+AZ0LnQmdDB0HHQ7tC+0CNUBToCo8+/qeQIBOVQnghW8A1UAzvdrIxaDfhN6H1kCJIulL6BoYW5/EnkIcRFoG6CzouyI+u+grKAY9bTnZwVAdtLnyhTnwH6h4ptQPwUscY7UEv4b+AX0AfVtkg0onccDHoF5TyAU5iC803TJeN8ryqeU00kpJS7RNjb8+49QxKRM8Rlj63dJV+hX0NvS5C0aUTvIcNT2ftcAW5P4yKJNIPjhx6AFoT4jHRJcr6Dptihd0A/RhGRhOOkPauefz5usgnuZmaR3by6BMqfoGegZqLv3bJxlR/lCz0mMKt42kP62Eeu3CUWALMq8MytSfZFx3rtfgGKUswMuYocqnK9Wf2qBeAXoFOsgJqvgD9EK0GrrZYwS5k7ub4CV4oOVlYBCZ9C5Un/rsBTmIPzQK17xK6W6N2+XrT+LAF3t8YU4VuwEG5MOU892qNZbRfQ19AX2idJdhidL9/lZokWX0LVAUWmj9m7QSpvW38nd/UBkGroWug0ye3ChjEZmQuFLpWaVO695x63kWWc/RZv2bPH+H9YzLlP6wfGKVU8q7UjnfKvWZnCAlAhW/kwMv8CvLiF6ErlN6gW+60nP9E5VeQJTB//r4ao9U/vBw5Quv7Q00Dq2dPj35ZfTVB4fUGI1w1uAI/M16+O8GnpQp3XQ4uZKufHL/0LrQBl4jOFI+HsnVdVlRN/DMeHavERoFjVY+/J0vtCH+v82gra1ySnkboQOgC5VedBSn+8iBOr7ZqXdObGKFUdyex8uSvrG0OrLabXiMetfyEwZKLBYcbDzq6ijoEaXXQHKt83/LR8at569IlKzk6u5Nri9LuhtlsQHAQHGQbtAySgt1bR51Lt1WTv2WErQgG6PSX8/zZb0EzUJ3Y103yzBQHETpsJYaqwuaz+q9tNqGW89fkXjrgkOlb1tAv1gGpBKPtR/kSrZcuTuI1xeUqOBa6HJoaQF1/b7XCG+Y/Y7EUVDx0wp4ad1aAf0Fml3rbyjpeKScHUT5gl7UyR1Kz+AVWseudw8rFlT+nx14gd9/6ZQODd8VBjIq+90Lo5wcxOsLDUO3VdaUJKT/HeXcdO9y5Q+NLeazkwyg8rdVel7fKScRybpARCXD1EMTlS9clEjVcnAQDLwl4vlYpcdlyx10DJGM945S/iAXCt1E6SSnfznsJN2SBbT5SkcH7w5tpAIhR164Gw6iJOvRCPmUTpp6QenAzmLkw8gY7xJZzHTiuUmBKL3ItbhITtLzpcs08W3QgdB4ZYTz3hmwFA6i/H5ZbZcpcQnmlEzIV1R+axm5SFbPz4e4B1Y54TXC2+Cl/Mky5GIaQM/W5UXLGHaDxkHre23GHhXDQZTOR99SJdN9Q8cr5wbadiTdMwnB2bewN0mKhtLhFf+hnB+X2JGk10oY+s9VMgwmmPH0I6ccJBlKYgQlVEQifB+CPlalj/SVsksuDlfMBwIwGhl8Xmx90dwKC5f7/h90CjQT2k71WHPJx0E8/qCE2Eh8WAg6QulZt2J3mTJJgh0lm9Dj3tsmebGDUT9E+ZPdjQstR1ntoiFJRuF70MtK74hywLHBuqZXmiYsnNdcnYj2cIYI9Db+7dWmCYkXpk5MPNo4KXF1g3oKvzlb6V1LWq0vtltlEcng/h6o2WOEmBg1kPEaIRmojlV6YH2vZahu51F8UwsjmxEIrNovYCQOrfcljoAOgw6G9sW/zQwEEk3++kTAH0zUuvusou7NGiTP/6eQLCRWxklPlQTGKEMwmJe9pI5Wej+rck+2clvSTXxe6ejnqRjr8DyPSkG6BkqPC2Rw+7DSYdluG2Q5SLqiryo92dCs/GFXgzpJmaDqAhgAB6crncr6mireIlq5ScYzkh0p+1zJLoubuP0uSJmDwb2sOFcrnWEns2Gy6ixjl3LeKMGuPlM63ko21JOtRw3lC67n9TkTIUAqkJpggwz011N6cHoe9KTS+d0yzenGbo12JM4s+Rv/hN5QOrZsFrSph9uGkmKDVmY0jE2CJWXTZ1lNlzAOtwf9EkWwwGodfqx0PscY5Wvg1qDEXTz+ZBLXzsqZjQ7y0SroRmWEix6qT0hOWCEuP7O6M262IDIDdSe0ldt1QkgSJVsC6Zkvt8ccPSW72U9wu25IhaN09OwVyoEwljojmKj3BxNhf33Ch//tgJPImGi823VEKhgY4KGqgLCVqXCGk4NTEpeFVeKOxh0SDzdOSvx56qTEXY3bJy7Fv+0V8BfiILKG81StYf9YOEIcQ+mj2vIZkMs6xP2z641D5jdXt2SK4pUgxuemTkycEpwiyWBdeTrKHFVfzzUOUjqUP7mz49t5fNEl/msyNCqXcHc4kqT8joMushwsl/tKht9Ut+uMVBBKHz2Wy6r6XCXnI/p/CA3PJx9EBZILlhJs+USO93+5po4r5aQEeI3kro4LczDOR9HibJF6nQLPB5FDSS/N4RlkEmGP0tUSqVhgaKcqvShnxzAlqSjtwp1Dx0BflMOzyEm1WXedJ6QglA4Ft2OQr3l8Df2uajvhIJ5A8oyUu20+j0wo+IpXM6Tisbo2dnZNkanf3TNdy7FNG3xhOetjmU0nOd/5WiHEQum0XTuG+KryBzNu2OzoATp6Yzs7z/VXZ2uEEAuPL5nbfodNQ7wl2/UcdpAjbD6X7EA52rlaIcRC6Zirt2wa4rXZruewg8yy+Vzfeo1wWRwgRAYZ1kbP820a4jXZruewg0hOip30YPkbHqpJnMdqQeyunt+Z7XoOO8iP7bYgqkyOoCODDI8+OPQ5m4b4ptdoGJPpeg47yFk2n+szZYQ3d7ZmCLFQepHQjiGKZme6llMOAseVDSYiNp9pnvO1QoiF8oWqlP0YqBe9oVC/ueDObV4d+onN8YfopuLUDCEWSh95YLcVOcdrBNM6iUOhJrLLysc2n+V9ZQQnF7d2SMUDQztY6WPa7Bjlh+jzpw0SLNRBcO0fqdyOwr4Pz8LkKVJclD8o8U835dCtkZ0LT4Rx9trsOV8HqfGHh6CrN0Xp3RDtOker1xfcrPS1RSoSrxHaROnDcuwaqJxGdStUpawdDPPLB0nunrK/0sc52L23JFjx1CdSWpROuX0vB0MVyUJjs/w+VwepqUs6hyRq5brJ9oVoPbhxHCk9ML5AHk4iyUuPH1bv2zvaXBXN5hzvNFcnftngkR1KFuR4H1kUvNIbYiYhcQkrgHFvlfsxaGumGMFPfhqcsuJvTRN6nTDVrflwjIcaJyUP1TGMYK67zMvf3+JhYCJxm1oZNBvJQXNep8nKCVL7BIzE6cHJye1/LgjVJk+cmuavT0zO43pKj3fO8nLGipQTMMrtob/m4yQOStJvZ3v83AuLlCHKH5Lsvj9YX/FSOoZ0qd6EZrhdB4RkRBnJdRKZio2XsNWQ7U95MhQZOHiM4EZKn31YzNZEghR3crushOQFjFcibU9SemHPyfMOZfHvdmis22UkpGCUPolKjkj40IHulJyXuKPiQJwMJib5/TIdnEsMVzrJuYjMCCSDC68vtJHVJfqqwBZEclHmcdxBBgXoBkmr0aT05tVOjkHkdF3JNeFWomRgIjFQMOK9VPFOvpXW5HpofbfLSkhOKH2m+hxVmjPUX5JxibRWbpebkKx49PZAd6rczu8oVHIcQ8jtshOSEeVLJlK9lItxS0DiDH8gGaB4YnBK4uhgXfJsQiP3gzzlCOo93a4DQtKidI74I3YN2gvtFvCv+U1DTUJC3iM9Qt3faqpO3Ne4feLM0OTElNyc5ANoRk1dkN0tUj6g/y/TuK/kYMif7BQI3PxGU3VrtoSp++EoswJ+WSC0OwsmCVycBiblAYxxXaXXOOw6hyRXHf/k1Elb2025fWzqpMfwm6dycJLFcFouKBL3gTGeoewPyMU5DqjxhYfmmpOO322q9ODfrpNIi5bxjBJCigoMsF7pY5btGKysh3x/HHNeu5r4QqNwjdtsOon8zY3u1Q6paLzaWJ/NoeXYtefv890XS+lj4J60eV8Zu9SVvnZIxQPDO0zpswizGan8zUGpvy/wGOgtoFabTnKPJ9D/HsGEOM7kyY0SRmL3tNvLa/1996VyYOvRRptdLdnZkXvyktKhfOGJyt5pt7LCnfacEIc2r/6dTSfNeuIVIY4BgzvbpmHu3981HHKQCUqff57tOV4vXm0QkgIM7gkbRjnXE2gY1t81HHEQHU5/t51ulhEK9fsshDiKzfHHWZmu4eABOjIWWZ31efyhjZyvCULSoLIf5imD52mZruGgg4yEOm04SLXzNUFIGmBwb2QxSNl1ZGKmazh8iOfT2RzW46vf2tlaIKQfYHD3ZzFI2b1kfKZrOOwg92Z5nuWTVB0jfElpgMEdkcUgZUyQce3BYQfJtrL+rLM1QEgGPPqEqWzTq7tnuoZjx0D7g3KwzsIsz3Ky87VASAZgdA9mMcrzMv3esUG6P7SNyry96VI4NM8nJKVF6e18MkXyPpfp9w7OYh2XxVHnOF96QrLg9YeHKh16nmmqt9+ZLEcWCn3JcwszzajBgcNc/yDuAAOstaZ0+zPQ/60JpN+Ox6FQE5Xh/pLE9fPi1gAhWYARnq76zyiUBbyN0/3OIQe5KoNzPo/WY1RxS09IFpROYHosw3TvHul+V3C4uz8oRyss7ee+SzJ17wgpKV4jtLVllOmM9RlVF+wTKAij3xyK2HSQ61J/r3TCVrr7yb69u5Wm5ITYBN0ZOTO9q5+xQJ9WBC3IGBj+KzYd5OLe90qehbgozb1kq9Oj8SzMICTlBQxTQs/9Sm/elmq4c2uN0Miefx/dcdxQGP41NpxjJXRwyr2OSjPukSnn0z119XQOUr7ASJvTdLdk84Q+24K2TKueBONfkcVB3og1T9jwh+uHZczTkXJ9mck61WMw95yUOV6dxCTTv/NTjHhxrb9vAhUc4GyrlUjnHB/Emqo8Pf8e1zmnj3P4Q3t5jb7jHELKFuVLfunvVb2TmU6rCzb2WReBI8yEnoeWQ59BS6HboV67I+L341Jap7cUj2QjAxV0h2Qq9lhomWXQMi27Zbq/jU2rHmHNbI2FNsYgvk+LgN/eovQK/QroWoir5GTgI195pXNIZKxwVF7X8IfG4LftSmcz7qc43iCDCW8gGZY+w2uEavL6vT80HL+f5fWHN3f62QghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhJABy/8Dr0nIgxoAG2IAAAAASUVORK5CYII=');

-- LUNDI

INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (1, '8:00'), (1, '8:15'), (1, '8:30'), (1, '8:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (1, '9:00'), (1, '9:15'), (1, '9:30'), (1, '9:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (1, '10:00'), (1, '10:15'), (1, '10:30'), (1, '10:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (1, '11:00'), (1, '11:15'), (1, '11:30'), (1, '11:45');

INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (1, '13:30'), (1, '13:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (1, '14:00'), (1, '14:15'), (1, '14:30'), (1, '14:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (1, '15:00'), (1, '15:15'), (1, '15:30'), (1, '15:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (1, '16:00'), (1, '16:15'), (1, '16:30'), (1, '16:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (1, '17:00'), (1, '17:15'), (1, '17:30'), (1, '17:45');

-- MARDI

INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (2, '8:00'), (2, '8:15'), (2, '8:30'), (2, '8:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (2, '9:00'), (2, '9:15'), (2, '9:30'), (2, '9:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (2, '10:00'), (2, '10:15'), (2, '10:30'), (2, '10:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (2, '11:00'), (2, '11:15'), (2, '11:30'), (2, '11:45');

INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (2, '13:30'), (2, '13:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (2, '14:00'), (2, '14:15'), (2, '14:30'), (2, '14:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (2, '15:00'), (2, '15:15'), (2, '15:30'), (2, '15:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (2, '16:00'), (2, '16:15'), (2, '16:30'), (2, '16:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (2, '17:00'), (2, '17:15'), (2, '17:30'), (2, '17:45');

-- MERCREDI

INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (3, '8:00'), (3, '8:15'), (3, '8:30'), (3, '8:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (3, '9:00'), (3, '9:15'), (3, '9:30'), (3, '9:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (3, '10:00'), (3, '10:15'), (3, '10:30'), (3, '10:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (3, '11:00'), (3, '11:15'), (3, '11:30'), (3, '11:45');

INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (3, '13:30'), (3, '13:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (3, '14:00'), (3, '14:15'), (3, '14:30'), (3, '14:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (3, '15:00'), (3, '15:15'), (3, '15:30'), (3, '15:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (3, '16:00'), (3, '16:15'), (3, '16:30'), (3, '16:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (3, '17:00'), (3, '17:15'), (3, '17:30'), (3, '17:45');

-- JEUDI

INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (4, '8:00'), (4, '8:15'), (4, '8:30'), (4, '8:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (4, '9:00'), (4, '9:15'), (4, '9:30'), (4, '9:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (4, '10:00'), (4, '10:15'), (4, '10:30'), (4, '10:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (4, '11:00'), (4, '11:15'), (4, '11:30'), (4, '11:45');

INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (4, '13:30'), (4, '13:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (4, '14:00'), (4, '14:15'), (4, '14:30'), (4, '14:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (4, '15:00'), (4, '15:15'), (4, '15:30'), (4, '15:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (4, '16:00'), (4, '16:15'), (4, '16:30'), (4, '16:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (4, '17:00'), (4, '17:15'), (4, '17:30'), (4, '17:45');

-- VENDREDI

INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (5, '8:00'), (5, '8:15'), (5, '8:30'), (5, '8:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (5, '9:00'), (5, '9:15'), (5, '9:30'), (5, '9:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (5, '10:00'), (5, '10:15'), (5, '10:30'), (5, '10:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (5, '11:00'), (5, '11:15'), (5, '11:30'), (5, '11:45');

INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (5, '13:30'), (5, '13:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (5, '14:00'), (5, '14:15'), (5, '14:30'), (5, '14:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (5, '15:00'), (5, '15:15'), (5, '15:30'), (5, '15:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (5, '16:00'), (5, '16:15'), (5, '16:30'), (5, '16:45');
INSERT INTO weekly_time_slots(week_day, start_hour) VALUES (5, '17:00'), (5, '17:15'), (5, '17:30'), (5, '17:45');

-- UTILISATEURS

INSERT INTO users(last_name, first_name, email, password, user_role, phone_number,enabled) VALUES ('Hallez', 'Nathan', 'nathan.hallez.etu@univ-lille.fr', '{noop}moi', 'USER', '0614341267',true);
INSERT INTO users(last_name, first_name, email, password, user_role, phone_number,enabled) VALUES ('Lekehal', 'Ilyes', 'ilyes.lekehal.etu@univ-lille.fr', '{noop}moi', 'USER', '0630532743',true);
INSERT INTO users(last_name, first_name, email, password, user_role, phone_number,enabled) VALUES ('admin', 'admin', 'admin@localhost.net', '{noop}moi', 'ADMIN', '0320340223',true);


-- On ajoute quelques créneaux indépendants
INSERT INTO time_slots(start_date, start_hour, is_cancelled, cancel_reason) VALUES ('2024-02-01', '18:00', false, NULL);
INSERT INTO time_slots(start_date, start_hour, is_cancelled, cancel_reason) VALUES ('2024-02-01', '7:45', false, NULL);
INSERT INTO time_slots(start_date, start_hour, is_cancelled, cancel_reason) VALUES ('2024-02-02', '23:00', true, 'Beaucoup trop tard comme horaire finalement');
INSERT INTO time_slots(start_date, start_hour, is_cancelled, cancel_reason) VALUES ('2024-02-03', '19:00', false, NULL);
INSERT INTO time_slots(start_date, start_hour, is_cancelled, cancel_reason) VALUES ('2024-02-03', '6:00', true, 'Pas envie de me lever');

-- Annulation de deux réservations
UPDATE reservations SET is_cancelled = true, cancel_reason = '' WHERE user_id = 1;
UPDATE reservations SET is_cancelled = true, cancel_reason = 'Je ne suis plus malade' WHERE user_id = 2;

-- Quelques réservations
INSERT INTO reservations(user_id, time_slot_id, nb_persons, is_cancelled) VALUES (1, 1, 1, false);
INSERT INTO reservations(user_id, time_slot_id, nb_persons, is_cancelled) VALUES (2, 2, 1, false);
INSERT INTO reservations(user_id, time_slot_id, nb_persons, is_cancelled) VALUES (1, 3, 1, false);
INSERT INTO reservations(user_id, time_slot_id, nb_persons, is_cancelled) VALUES (2, 4, 1, false);
INSERT INTO reservations(user_id, time_slot_id, nb_persons, is_cancelled) VALUES (1, 5, 1, true);