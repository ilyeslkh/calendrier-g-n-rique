/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: 'rgb(239 68 68 / var(--tw-bg-opacity))',
        'primary-hover': 'rgb(185 28 28 / var(--tw-bg-opacity))',
        skeleton: 'rgb(209 213 219 / var(--tw-bg-opacity))'
      }
    }
  },
  plugins: []
}
