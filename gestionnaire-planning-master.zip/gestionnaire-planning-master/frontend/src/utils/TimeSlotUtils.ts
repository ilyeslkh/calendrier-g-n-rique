import moment from 'moment'
import { useRoute } from 'vue-router'

export interface Slot {
  start: string
  end: string
}

export function getTimeSlotsFromInterval(start: Date, end: Date, slotDuration: number) {
  const interval = (end.getTime() - start.getTime()) / 60000
  const nbToAdd = Math.floor(interval / slotDuration)
  const res: Date[] = []
  const toAdd = new Date(start)
  for (let i = 0; i < nbToAdd; i++) {
    res.push(new Date(toAdd))
    toAdd.setMinutes(toAdd.getMinutes() + slotDuration)
  }
  return res
}

export function getCurrentDate() {
  const current = new Date()
  current.setHours(0, 0, 0, 0)
  return current
}

export function parseYearMonthAndDay() {
  const route = useRoute()
  let year = parseInt((route.query.year || '') as string)
  let month = parseInt((route.query.month || '') as string)
  let day = parseInt((route.query.day || '') as string)
  if (!year || !month || !day) {
    year = new Date().getFullYear()
    month = new Date().getMonth()
    day = new Date().getDay()
  } else {
    month = month - 1
  }
  return new Date(year, month, day)
}

const CHOICE_INTERVAL = 30.0

export function updateSlotsOptions(startHours: string[], endHours: string[], duration: number) {
  const date = new Date()
  date.setHours(0)
  date.setMinutes(0)
  let oldDate = new Date(date)
  while (oldDate.getDay() == date.getDay()) {
    if (date.getHours() * 60 + date.getMinutes() <= 24 * 60 - duration - 60) {
      startHours.push(moment(date).format('HH:mm'))
    }
    oldDate = new Date(date)
    endHours.push(moment(date).format('HH:mm'))
    date.setMinutes(date.getMinutes() + CHOICE_INTERVAL)
  }
}

export function updateSlotSelection(
  startHours: string[],
  endHours: string[],
  slot: Slot,
  duration: number
) {
  if (!startHours.includes(slot.start)) {
    slot.start = startHours[startHours.length - 1]
  }
  if (!getEndHours(slot, endHours, duration).includes(slot.end)) {
    slot.end = endHours[0]
  }
}

export function getEndHours(slot: Slot, endHours: string[], duration: number): string[] {
  //const slot = formData.planning[day][slotIndex]
  const index =
    endHours.findIndex((hour) => hour == slot.start) + Math.ceil(duration / CHOICE_INTERVAL)
  if (slot.end <= endHours[index]) {
    slot.end = endHours[index]
  }
  return endHours.slice(index)
}

export function computeSlotEnd(startHour: string) {
  const splitted = startHour.split(':')
  const date = new Date()
  date.setHours(parseInt(splitted[0]))
  date.setMinutes(parseInt(splitted[1]))
  date.setMinutes(date.getMinutes() + 60)
  return moment(date).format('HH:mm')
}
