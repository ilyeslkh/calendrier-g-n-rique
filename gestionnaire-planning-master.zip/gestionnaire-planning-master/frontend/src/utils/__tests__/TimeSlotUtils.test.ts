import { describe, it, expect } from "vitest";
import { getTimeSlotsFromInterval } from "../TimeSlotUtils";

/**
 * Retourne une date arbitraire avec une heure et minutes données en paramètres
 */
function dateHourMinutes(hours: number, minutes: number) {
    return new Date(2023, 10, 30, hours, minutes);
}

describe('time slots from interval', () => {
    it('should return no time slots if the interval is too short', () => {
        const start = dateHourMinutes(8, 0);
        const end = dateHourMinutes(8, 1);
        const slotDuration = 60;
        expect(getTimeSlotsFromInterval(start, end, slotDuration)).toStrictEqual([]);
    });

    it('should return one time slot if the interval is equal to slot duration', () => {
        const start = dateHourMinutes(8, 0);
        const end = dateHourMinutes(9, 0);
        const slotDuration = 60;
        expect(getTimeSlotsFromInterval(start, end, slotDuration)).toStrictEqual([dateHourMinutes(8, 0)]);
    });

    it('should return two time slots if the interval can contain two slots', () => {
        const start = dateHourMinutes(8, 0);
        const end = dateHourMinutes(10, 0);
        const slotDuration = 60;
        expect(getTimeSlotsFromInterval(start, end, slotDuration)).toStrictEqual([dateHourMinutes(8, 0), dateHourMinutes(9, 0)]);
    })

    it('should leave empty space at the end if it can\'t contain a last time slot', () => {
        const start = dateHourMinutes(8, 0);
        const end = dateHourMinutes(9, 10);
        const slotDuration = 20; // Toutes les 20 minutes
        expect(getTimeSlotsFromInterval(start, end, slotDuration)).toStrictEqual([
            dateHourMinutes(8, 0),
            dateHourMinutes(8, 20),
            dateHourMinutes(8, 40)
        ]);
    });
});