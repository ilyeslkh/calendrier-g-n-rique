<script setup lang="ts">
import router from '@/router'
import { useAPI } from '@/stores/api'
import { useConfigStore } from '@/stores/config'
import { useToken } from '@/stores/token'
import { updateSlotsOptions, getEndHours } from '@/utils/TimeSlotUtils'
import moment from 'moment'
import { type Ref, ref } from 'vue'

interface Slot {
  start: string
  end: string
}

const startDate: Ref<string> = ref(moment(new Date()).format('yyyy-MM-DD'))
const startHours: Ref<string[]> = ref([])
const hours: Ref<string[]> = ref([])
const slot: Ref<Slot> = ref({ start: '09:00', end: '17:00' })
const overlapError = ref(false)
const inThePastError = ref(false)

function submitForm() {
  inThePastError.value = false
  overlapError.value = false
  useAPI()
    .instance.post('/timeslots', {
      startDate: startDate.value,
      startTime: slot.value.start,
      endTime: slot.value.end
    })
    .catch((e) => {
      if (e.response.status == 400) {
        inThePastError.value = true
      } else if (e.response.status == 409) {
        overlapError.value = true
      }
    })
    .then((response) => {
      if (!response) return
      const date = new Date(startDate.value)
      router.push({
        name: 'Calendrier',
        query: { year: date.getFullYear(), month: date.getMonth() + 1 }
      })
    })
}

updateSlotsOptions(startHours.value, hours.value, useConfigStore().slotDuration)
</script>

<template>
  <div class="flex grow flex-col items-center justify-center" v-if="useToken().isAdmin()">
    <form @submit.prevent="submitForm()" class="w-96">
      <div class="mb-4">
        <label for="end">Date de début</label>
        <input
          type="date"
          class="form-input"
          v-model="startDate"
          :min="moment(new Date()).format('yyyy-MM-DD')"
        />
      </div>
      <div class="mb-4">
        <div class="grid w-full grid-cols-12 items-center justify-start gap-2">
          <div class="col-span-6">
            <label for="start">Heure de début</label>
            <select id="start" class="form-input" v-model="slot.start">
              <option v-for="hour of startHours" :key="hour">
                {{ hour }}
              </option>
            </select>
          </div>
          <div class="col-span-6">
            <label for="end">Heure de fin</label>
            <select class="form-input" id="end" v-model="slot.end">
              <option
                v-for="hour of getEndHours(slot, hours, useConfigStore().slotDuration)"
                :key="hour"
              >
                {{ hour }}
              </option>
            </select>
          </div>
        </div>
        <span class="text-sm" v-if="overlapError"
          >Un ou plusieurs créneaux existent déjà entre ces horaires!</span
        >
        <span class="text-sm" v-if="inThePastError"
          >Vous ne pouvez pas créer des créneaux dans le passé!</span
        >
      </div>
      <button type="submit" class="btn-primary w-full">Ajouter</button>
    </form>
  </div>
  <div v-else></div>
</template>
