<template>
  <header
    class="flex flex-col items-center gap-5 border-b-2 border-b-gray-200 bg-white p-4 min-[1000px]:flex-row min-[1000px]:gap-20"
  >
    <router-link to="/" class="flex items-center gap-2" v-show="!useConfigStore().loading">
      <service-logo class="h-10 w-10" />
      <h1 class="max-w-[12em] overflow-hidden text-ellipsis whitespace-nowrap font-bold">
        {{ useConfigStore().name }}
      </h1>
    </router-link>
    <ConfigSkeleton v-if="useConfigStore().loading" />

    <nav class="flex w-full flex-col justify-between gap-3 min-[700px]:flex-row min-[700px]:gap-0">
      <ul class="flex flex-col items-center justify-center gap-4 min-[425px]:flex-row">
        <li>
          <router-link
            class="flex items-center gap-2 rounded-2xl px-6 py-2 hover:bg-gray-200"
            to="/"
          >
            <CalendarDays class="w-8" />Calendrier
          </router-link>
        </li>
        <li>
          <router-link
            class="flex items-center gap-2 rounded-2xl px-6 py-2 hover:bg-gray-200"
            to="/next-meetings"
          >
            <AlarmCheck class="w-8" s />Mes réservations
          </router-link>
        </li>
      </ul>
      <div class="flex items-center justify-center gap-4">
        <login-header />
      </div>
    </nav>
  </header>
</template>

<script setup lang="ts">
import { CalendarDays } from 'lucide-vue-next'
import { AlarmCheck } from 'lucide-vue-next'
import { useConfigStore } from '@/stores/config'
import LoginHeader from '@/components/LoginHeader.vue'
import ConfigSkeleton from '@/components/skeletons/ConfigSkeleton.vue'
import ServiceLogo from '@/components/ServiceLogo.vue'
</script>
