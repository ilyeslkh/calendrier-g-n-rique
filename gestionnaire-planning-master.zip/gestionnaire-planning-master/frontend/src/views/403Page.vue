<script setup lang="ts"></script>
<template>
  <div class="flex grow flex-col items-center justify-center gap-8">
    <div>
      <h1 class="text-center text-9xl font-bold">403</h1>
      <p class="text-center text-3xl font-bold">Accès refusé</p>
    </div>

    <p class="text-center">Vous n'avez pas le droit d'accéder à cette page ou cette ressource.</p>

    <router-link to="/" class="btn btn-primary w-fit">Retourner sur la page principale</router-link>
  </div>
</template>
