<script lang="ts">
export function getFirstDayOfCalendar(month: number, year: number) {
  const date = new Date(year, month, 1)
  if (date.getDay() == 1) {
    date.setDate(date.getDay() - 7)
    return date
  }
  if (date.getDay() == 0) {
    date.setDate(date.getDay() - 5)
    return date
  }
  date.setDate(date.getDate() - date.getDay() + 1)
  return date
}
</script>

<script setup lang="ts">
import { useAPI } from '@/stores/api'
import { useConfigStore } from '@/stores/config'
import { useToken } from '@/stores/token'
import { PlusIcon } from 'lucide-vue-next'
import { ChevronLeft, ChevronRight } from 'lucide-vue-next'
import moment from 'moment'
import { onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { getCurrentDate } from '@/utils/TimeSlotUtils'

const weekDays = ref(['Lun.', 'Mar.', 'Mer.', 'Jeu.', 'Ven.', 'Sam.', 'Dim.'])
const router = useRouter()

let loading = ref(true)

interface CalendarCell {
  date: Date
  percent: number
}

let selectedMonth = ref(new Date())
let calendar = ref<CalendarCell[]>([])

function updateCalendar() {
  loading.value = true
  calendar.value = []
  const date = getFirstDayOfCalendar(
    selectedMonth.value.getMonth(),
    selectedMonth.value.getFullYear()
  )

  for (let i = 0; i < 42; i++) {
    calendar.value.push({
      date: new Date(date),
      percent: 0
    })
    date.setDate(date.getDate() + 1)
  }
  setColorsOfCells()
}

function goToPreviousMonth() {
  selectedMonth.value.setMonth(selectedMonth.value.getMonth() - 1)
  router.push({
    query: { year: selectedMonth.value.getFullYear(), month: selectedMonth.value.getMonth() + 1 }
  })
  updateCalendar()
}

function goToNextMonth() {
  selectedMonth.value.setMonth(selectedMonth.value.getMonth() + 1)
  router.push({
    query: { year: selectedMonth.value.getFullYear(), month: selectedMonth.value.getMonth() + 1 }
  })
  updateCalendar()
}

onMounted(() => {
  const route = useRoute()
  let year = parseInt((route.query.year || '') as string)
  let month = parseInt((route.query.month || '') as string)
  if (!year || !month) {
    year = new Date().getFullYear()
    month = new Date().getMonth()
  } else {
    month = month - 1
  }
  selectedMonth.value = new Date(year, month)
  updateCalendar()
})

function isInSelectedMonth(date: Date) {
  return date.getMonth() == selectedMonth.value.getMonth()
}

function formatDateCell(date: Date) {
  if (date.getDate() == 1) {
    return date.toLocaleDateString('fr-FR', { month: 'short' })
  } else {
    return ''
  }
}

function getGradientColor(cell: CalendarCell) {
  if (!isInSelectedMonth(cell.date) || loading.value) {
    return 'hsl(0,0%,94%)'
  }
  return `hsl(${cell.percent.toString(10)},100%,70%)`
}

function setColorsOfCells() {
  useAPI()
    .instance.get(
      `/timeslots/${selectedMonth.value.getFullYear()}/${
        selectedMonth.value.getMonth() + 1
      }/avgMonth`
    )
    .then((response) => {
      loading.value = false
      for (const date of response.data) {
        const found = calendar.value.find(
          (c) => moment(c.date).format('yyyy-MM-DD') == date.startDate
        )
        if (found) {
          if (date.nbTimeSlots == 0) {
            found.percent = 0
          } else {
            found.percent =
              (1 - date.nbPersons / (useConfigStore().nbPersonMax * date.nbTimeSlots)) * 100
          }
        }
      }
    })
}

function isCurrentDate(date: Date) {
  const current = new Date()
  return (
    date.getFullYear() == current.getFullYear() &&
    date.getMonth() == current.getMonth() &&
    date.getDate() == current.getDate()
  )
}
</script>

<template>
  <main class="flex flex-1 flex-col gap-5 p-4">
    <section class="flex justify-between">
      <div class="flex w-fit items-center gap-3 rounded-2xl bg-white px-8 py-3">
        <ChevronLeft
          @click="goToPreviousMonth"
          class="cursor-pointer"
          v-if="
            selectedMonth.getMonth() > new Date().getMonth() ||
            selectedMonth.getFullYear() > new Date().getFullYear() ||
            useToken().isAdmin()
          "
        />
        <div v-else class="w-6"></div>
        <ChevronRight @click="goToNextMonth" class="cursor-pointer" />
        <h2 class="select-none text-2xl font-bold capitalize">
          {{ selectedMonth.toLocaleString('fr-FR', { month: 'long' }) }}
          {{ selectedMonth.getFullYear() }}
        </h2>
      </div>
      <RouterLink
        to="/add"
        class="btn btn-primary flex items-center gap-2"
        v-if="useToken().isAdmin()"
      >
        <PlusIcon /> Ajouter un créneau
      </RouterLink>
    </section>

    <section class="flex flex-1 flex-col">
      <div class="flex justify-between">
        <div
          class="flex h-12 w-full items-center justify-center bg-primary text-center uppercase text-white first:rounded-tl-2xl last:rounded-tr-2xl"
          v-for="weekDay of weekDays"
          :key="weekDay"
        >
          <p>{{ weekDay }}</p>
        </div>
      </div>
      <div class="grid flex-1 auto-rows-fr grid-cols-7 grid-rows-6 gap-px rounded-2xl bg-gray-300">
        <div
          v-for="calCell in calendar"
          :key="calCell.date.getUTCMilliseconds()"
          class="flex h-full w-full grid-cols-2 bg-white p-1 text-left last:rounded-br-2xl [&:nth-child(36)]:rounded-bl-2xl"
        >
          <div
            class="mr-2 h-full w-3 rounded transition delay-100 ease-in-out"
            :style="'background-color: ' + getGradientColor(calCell)"
          ></div>
          <div>
            <div v-if="isCurrentDate(calCell.date)" class="flex items-center gap-1">
              <div
                class="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-white"
              >
                <p>{{ calCell.date.getDate() }}</p>
              </div>
              <p>{{ formatDateCell(calCell.date) }}</p>
            </div>
            <p
              v-else
              :class="{ 'text-gray-400': !isInSelectedMonth(calCell.date) }"
              class="flex h-8 items-center"
            >
              {{ calCell.date.getDate() + ' ' + formatDateCell(calCell.date) }}
            </p>
            <router-link
              :to="
                '/day?year=' +
                calCell.date.getFullYear() +
                '&month=' +
                (calCell.date.getMonth() + 1) +
                '&day=' +
                calCell.date.getDate()
              "
              v-if="
                (calCell.date >= getCurrentDate() || useToken().isAdmin()) &&
                isInSelectedMonth(calCell.date)
              "
              >Voir plus</router-link
            >
          </div>
        </div>
      </div>
    </section>
  </main>
</template>
