<template>
  <div class="mt-8 flex grow flex-col items-center">
    <SegmentedControl>
      <SegmentedElement
        link="/account/personal-infos"
        name="Informations personnelles"
      ></SegmentedElement>
      <SegmentedElement link="/account/security" name="Securité"></SegmentedElement>
    </SegmentedControl>
    <div class="w-full max-w-lg">
      <AlertInfo
        class="mb-4"
        title="Modifications effectuées"
        description="Votre mot de passe a changé"
        v-if="modified"
      ></AlertInfo>

      <form @submit.prevent="submitForm" novalidate>
        <div class="mb-4">
          <label for="password">Ancien mot de passe</label>
          <input
            class="form-input"
            id="password"
            name="password"
            type="password"
            placeholder="******************"
            v-model="formData.oldPassword"
            @input="() => (incorrectPassword = false)"
          />
          <span v-if="$v.oldPassword?.$error"> {{ $v.oldPassword?.$errors[0].$message }} </span>
          <span v-if="incorrectPassword">Ancien mot de passe invalide</span>
        </div>
        <div class="mb-4">
          <label for="password">Nouveau mot de passe</label>
          <input
            class="form-input"
            id="password"
            name="password"
            type="password"
            placeholder="******************"
            v-model="formData.newPassword"
          />
          <span v-if="$v.newPassword?.$error"> {{ $v.newPassword?.$errors[0].$message }} </span>
        </div>
        <div class="mb-4">
          <label for="password">Confirmation du nouveau mot de passe</label>
          <input
            class="form-input"
            id="password"
            name="password"
            type="password"
            placeholder="******************"
            v-model="formData.confirmation"
          />
          <span v-if="$v.confirmation?.$error"> {{ $v.confirmation?.$errors[0].$message }} </span>
        </div>
        <input type="submit" class="btn-primary w-full" value="Changer le mot de passe" />
      </form>
    </div>
  </div>
</template>
<script setup lang="ts">
import SegmentedControl from '@/components/SegmentedControl.vue'
import SegmentedElement from '@/components/SegmentedElement.vue'
import { useAPI } from '@/stores/api'
import { useHeader } from '@/stores/header'
import useVuelidate from '@vuelidate/core'
import { helpers } from '@vuelidate/validators'
import { ref } from 'vue'
import AlertInfo from '@/components/AlertInfo.vue'

const incorrectPassword = ref(false)
const modified = ref(false)

const submitForm = async () => {
  const isFormCorrect = await $v.value.$validate()
  if (!isFormCorrect) return
  useAPI()
    .instance.patch('/users/password', {
      oldPassword: formData.value.oldPassword,
      newPassword: formData.value.newPassword
    })
    .catch((e: any) => {
      if (e.response.status == 400) {
        incorrectPassword.value = true
      }
    })
    .then((response) => {
      if (!response) return
      useHeader().updateUserDetails(response.data)
      formData.value.oldPassword = ''
      formData.value.newPassword = ''
      formData.value.confirmation = ''
      $v = useVuelidate(rules, formData)
      modified.value = true
    })
}

useAPI()
  .instance.get('/users')
  .then((response) => (formData.value = response.data))

const formData = ref({
  oldPassword: '',
  newPassword: '',
  confirmation: ''
})

const rules = {
  oldPassword: {
    required: helpers.withMessage('Champ obligatoire', (value: string) => !!value.trim())
  },
  newPassword: {
    required: helpers.withMessage('Champ obligatoire', (value: string) => !!value.trim())
  },
  confirmation: {
    required: helpers.withMessage('Champ obligatoire', (value: string) => !!value.trim()),
    equal: helpers.withMessage(
      'Les mots de passe ne sont pas identiques',
      () => formData.value.newPassword == formData.value.confirmation
    )
  }
}

let $v = useVuelidate(rules, formData)
</script>
