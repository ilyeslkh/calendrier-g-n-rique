<script setup lang="ts">
import AlertInfo from '@/components/AlertInfo.vue'
import router from '@/router'
import { useConfigStore } from '@/stores/config'
import { useToken } from '@/stores/token'
import useVuelidate from '@vuelidate/core'
import { helpers, required } from '@vuelidate/validators'
import { onBeforeMount, ref } from 'vue'
import ServiceLogo from '@/components/ServiceLogo.vue'
import { useHeader } from '@/stores/header'

const formData = ref({
  email: '',
  password: ''
})

const incorrectCredentials = ref(false)
const tokenExpired = ref(false)

const rules = {
  email: {
    required: helpers.withMessage('Champ obligatoire', required),
    email: helpers.withMessage('Format e-mail invalide', (value: string) =>
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)
    )
  },
  password: { required: helpers.withMessage('Champ obligatoire', required) }
}

const $v = useVuelidate(rules, formData)

const submitForm = async () => {
  const isFormCorrect = await $v.value.$validate()
  if (!isFormCorrect) return
  incorrectCredentials.value = !(await useToken().login(
    formData.value.email,
    formData.value.password
  ))
  if (!incorrectCredentials.value) {
    const redirect = router.currentRoute.value.query.redirect as string
    if (redirect == undefined) {
      router.push({ path: '/' })
      return
    }
    let uri = redirect.split('?')[1]
    const params = {} as any
    new URLSearchParams(uri).forEach((value, key) => {
      params[key] = value
    })
    router.push({
      path: (router.currentRoute.value.query.redirect as string) || '/',
      query: params
    })
  }
}

onBeforeMount(async () => {
  if (useToken().expired) {
    useToken().disconnect()
    useHeader().fetchUserDetails()
    await useConfigStore().getConfig()
    tokenExpired.value = true
  }
})
</script>

<template>
  <div class="flex grow items-center justify-center">
    <div class="w-full max-w-lg">
      <form
        @submit.prevent="submitForm"
        class="relative mt-12 w-full max-w-lg rounded-xl bg-white p-6 pt-10 shadow-lg"
        novalidate
      >
        <div class="flex w-full flex-col items-center justify-center gap-2">
          <service-logo class="absolute top-[-50px] mb-6 h-20 w-20" />
          <h1 class="mb-6 text-2xl font-bold">Page de connexion</h1>
        </div>
        <alert-info
          class="mb-4"
          title="Session expirée"
          description="Veuillez vous reconnecter"
          v-if="tokenExpired"
        />
        <alert-info
          v-if="router.currentRoute.value.query.automatic != undefined"
          class="mb-4"
          title="Connexion obligatoire"
          description="Vous devez vous connecter pour pouvoir accéder à cette page"
        />
        <alert-info
          v-if="router.currentRoute.value.query.confirmed != undefined"
          class="mb-4"
          title="Compte crée"
          description="Votre adresse e-mail a été confirmée, veuillez-vous connecter"
        />
        <div class="mb-4">
          <label for="email">Adresse e-mail</label>
          <input
            class="form-input"
            id="email"
            name="email"
            type="text"
            placeholder="Adresse e-mail"
            v-model="formData.email"
            @input="() => (incorrectCredentials = false)"
          />
          <span v-if="$v.email?.$error"> {{ $v.email?.$errors[0].$message }} </span>
        </div>

        <div>
          <label for="password">Mot de passe</label>
          <input
            class="form-input"
            id="password"
            name="password"
            type="password"
            placeholder="******************"
            v-model="formData.password"
            @input="() => (incorrectCredentials = false)"
          />
          <span v-if="$v.password?.$error"> {{ $v.password?.$errors[0].$message }} </span>
        </div>
        <span v-if="incorrectCredentials">E-mail ou mot de passe incorrect</span>

        <input type="submit" class="btn-primary mt-6 w-full" value="Se connecter" />
        <p class="mt-4 text-center">
          Vous n'avez pas de compte?
          <router-link class="underline" to="/register">Se créer un compte</router-link>
        </p>
      </form>
    </div>
  </div>
</template>
