<script setup lang="ts">
import { onBeforeMount, ref } from 'vue'
import ServiceConfig from './ServiceConfig.vue'
import PlanningConfig from './PlanningConfig.vue'
import router from '@/router'
import { useConfigStore } from '@/stores/config'

let step = ref(0)

export interface Slot {
  start: string
  end: string
}

let service: { name: string; logo: Blob }
let planning: {
  slotDuration: number
  durationUnit: string
  nbPersonMax: number
  planning: Slot[][]
}

function next(data: any) {
  if (step.value == 0) {
    service = data
    step.value++
  } else {
    planning = data
    applyConfig()
  }
}

function applyConfig() {
  const formattedPlanning = [] as { day: number; start: string; end: string }[]
  planning.planning.forEach((slots, index) =>
    slots.forEach((slot) =>
      formattedPlanning.push({
        day: index + 1,
        start: slot.start,
        end: slot.end
      })
    )
  )
  const reader = new FileReader()
  reader.readAsDataURL(service.logo)
  reader.onloadend = () => {
    useConfigStore()
      .setConfig(
        service.name,
        reader.result,
        planning.slotDuration,
        planning.nbPersonMax,
        formattedPlanning
      )
      .then(() => router.push({ path: '/' }))
  }
}

onBeforeMount(() => {
  if (useConfigStore().name) {
    router.replace({ path: '/403' })
  }
})
</script>

<template>
  <div class="flex grow items-center justify-center">
    <div v-if="step == 0" class="mb-4 w-full">
      <ServiceConfig :onSubmit="next"></ServiceConfig>
    </div>
    <div v-if="step == 1">
      <PlanningConfig :onSubmit="next"></PlanningConfig>
    </div>
  </div>
</template>
