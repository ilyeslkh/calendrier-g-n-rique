<template>
  <div class="flex grow items-center justify-center">
    <div class="w-full max-w-lg">
      <form
        @submit.prevent="submitForm"
        novalidate
        class="relative mt-12 rounded-xl bg-white p-6 pt-10 shadow-lg"
      >
        <div class="flex w-full flex-col items-center justify-center gap-2">
          <service-logo class="absolute top-[-50px] mb-6 h-20 w-20" />
          <h1 class="mb-6 text-2xl font-bold">Page d'inscription</h1>
        </div>
        <alert-info
          class="mb-4"
          title="Demande de confirmation"
          :description="
            'Un e-mail de confirmation a été envoyé à ' +
            formData.email +
            '. Veuillez vérifier votre boîte de réception pour activer votre compte.'
          "
          v-if="confirmationSent"
        />
        <div class="mb-4">
          <label for="firstName">Prénom</label>
          <input
            class="form-input"
            id="firstName"
            name="firstName"
            type="text"
            placeholder="Prénom"
            v-model="formData.firstName"
          />
          <span v-if="$v.firstName?.$error"> {{ $v.firstName?.$errors[0].$message }} </span>
        </div>

        <div class="mb-4">
          <label for="lastName">Nom</label>
          <input
            class="form-input"
            id="lastName"
            name="lastName"
            type="text"
            placeholder="Nom"
            v-model="formData.lastName"
          />
          <span v-if="$v.lastName?.$error"> {{ $v.lastName?.$errors[0].$message }} </span>
        </div>

        <div class="mb-4 flex space-x-4">
          <div class="flex-1">
            <label for="email">E-mail</label>
            <input
              class="form-input"
              id="email"
              name="email"
              type="email"
              placeholder="example@example.com"
              v-model="formData.email"
              @input="() => (emailAlreadyUsed = false)"
            />
            <span v-if="$v.email?.$error"> {{ $v.email?.$errors[0].$message }} </span>
            <span v-if="emailAlreadyUsed">Cet e-mail est déjà utilisé</span>
          </div>

          <div class="flex-1">
            <label for="phone">Téléphone</label>
            <input
              class="form-input"
              id="phone"
              name="phone"
              type="tel"
              placeholder="Numéro de téléphone"
              v-model="formData.phoneNumber"
              @input="() => (phoneAlreadyUsed = false)"
            />
            <span v-if="$v.phoneNumber?.$error"> {{ $v.phoneNumber?.$errors[0].$message }} </span>
            <span v-if="phoneAlreadyUsed">Ce numéro est déjà utilisé</span>
          </div>
        </div>

        <div class="mb-4">
          <label for="password">Mot de passe</label>
          <input
            class="form-input"
            id="password"
            name="password"
            type="password"
            placeholder="******************"
            v-model="formData.password"
          />
          <span v-if="$v.password?.$error"> {{ $v.password?.$errors[0].$message }} </span>
        </div>

        <!-- ... D'autres champs de création ... -->

        <input type="submit" class="btn-primary w-full" value="Créer le compte" />
        <p class="mt-4 text-center">
          Vous avez déjà un compte?
          <router-link class="underline" to="/login">Se connecter</router-link>
        </p>
      </form>
    </div>
  </div>
</template>

<script setup lang="ts">
import useVuelidate from '@vuelidate/core'
import { helpers, required } from '@vuelidate/validators'
import { ref } from 'vue'
import { useAPI } from '@/stores/api'
import AlertInfo from '@/components/AlertInfo.vue'
import ServiceLogo from '@/components/ServiceLogo.vue'

const emailAlreadyUsed = ref(false)
const phoneAlreadyUsed = ref(false)
const confirmationSent = ref(false)

const formData = ref({
  firstName: '',
  lastName: '',
  email: '',
  phoneNumber: '',
  password: ''
})

const rules = {
  firstName: { required: helpers.withMessage('Champ obligatoire', required) },
  lastName: { required: helpers.withMessage('Champ obligatoire', required) },
  email: {
    required: helpers.withMessage('Champ obligatoire', (value: string) => !!value.trim()),
    email: helpers.withMessage('Format e-mail invalide', (value: string) =>
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)
    )
  },
  phoneNumber: {
    required: helpers.withMessage('Champ obligatoire', (value: string) => !!value.trim()),
    phone: helpers.withMessage('Format invalide', (value: string) =>
      /^(?:(?:\+|00)33|0)\s*[1-9](?:[\s.-]*\d{2}){4}$/.test(value)
    )
  },
  password: {
    required: helpers.withMessage('Champ obligatoire', (value: string) => !!value.trim())
  }
}

const $v = useVuelidate(rules, formData)

const submitForm = async () => {
  confirmationSent.value = false
  const isFormCorrect = await $v.value.$validate()
  if (!isFormCorrect) return
  try {
    const response = await useAPI().instance.post('/users', formData.value)
    if (response && response.status === 200) {
      // Enregistrement réussi
      confirmationSent.value = true
    }
  } catch (e: any) {
    if (e.response.status != 409) {
      return
    }
    if (e.response.data.message.startsWith('Phone')) {
      phoneAlreadyUsed.value = true
    } else {
      emailAlreadyUsed.value = true
    }
  }
}
</script>
