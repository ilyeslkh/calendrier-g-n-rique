<script setup lang="ts">
import router from '@/router'
import { useAPI } from '@/stores/api'
import { onMounted } from 'vue'
import { useRoute } from 'vue-router'

function confirmToken(token: String) {
  useAPI()
    .instance.post('/users/confirm', undefined, {
      headers: {
        Authorization: 'Bearer ' + token
      }
    })
    .catch((error) => {
      if (error.response.status === 403) {
        router.replace({ path: '/403' })
      }
      if (error.response.status === 404) {
        router.replace({ path: '/404' })
      }
    })
    .then((result) => {
      if (!result) return
      router.push({ path: '/login', query: { confirmed: '' } })
    })
}

onMounted(() => {
  const token = useRoute().query.token as String
  confirmToken(token)
})
</script>
