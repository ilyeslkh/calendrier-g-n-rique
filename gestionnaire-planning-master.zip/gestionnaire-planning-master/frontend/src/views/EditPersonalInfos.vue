<template>
  <div class="mt-8 flex grow flex-col items-center">
    <SegmentedControl>
      <SegmentedElement
        link="/account/personal-infos"
        name="Informations personnelles"
      ></SegmentedElement>
      <SegmentedElement link="/account/security" name="Securité"></SegmentedElement>
    </SegmentedControl>
    <div class="w-full max-w-lg">
      <AlertInfo
        class="mb-4"
        title="Modifications effectuées"
        description="Vos informations personnelles ont changé"
        v-if="modified"
      ></AlertInfo>
      <form @submit.prevent="submitForm" novalidate>
        <div class="mb-4 flex gap-4">
          <div
            id="preview"
            class="h-16 w-16 rounded-full bg-white bg-cover bg-center bg-no-repeat shadow"
            :style="'background-image: url(\'' + url + '\')'"
          ></div>
          <div class="flex flex-col gap-2">
            <p><strong>Modifier sa photo de profil</strong></p>
            <button class="btn btn-primary relative text-sm">
              <input
                id="logo"
                accept="image/*"
                type="file"
                multiple
                class="absolute inset-0 z-50 m-0 h-full w-full cursor-pointer p-0 opacity-0 outline-none"
                title=""
                @change="onFileChange"
              />Choisir un fichier...
            </button>
          </div>
        </div>
        <div v-if="!loading">
          <div class="mb-4">
            <label for="firstName">Prénom</label>
            <input
              class="form-input"
              id="firstName"
              name="firstName"
              type="text"
              placeholder="Prénom"
              v-model="formData.firstName"
            />
            <span v-if="$v.firstName?.$error"> {{ $v.firstName?.$errors[0].$message }} </span>
          </div>

          <div class="mb-4">
            <label for="lastName">Nom</label>
            <input
              class="form-input"
              id="lastName"
              name="lastName"
              type="text"
              placeholder="Nom"
              v-model="formData.lastName"
            />
            <span v-if="$v.lastName?.$error"> {{ $v.lastName?.$errors[0].$message }} </span>
          </div>

          <div class="mb-4 flex space-x-4">
            <div class="flex-1">
              <label for="email">E-mail</label>
              <input
                class="form-input"
                id="email"
                name="email"
                type="email"
                placeholder="example@example.com"
                v-model="formData.email"
                @input="() => (emailAlreadyUsed = false)"
              />
              <span v-if="$v.email?.$error"> {{ $v.email?.$errors[0].$message }} </span>
              <span v-if="emailAlreadyUsed">Cet e-mail est déjà utilisé</span>
            </div>

            <div class="flex-1">
              <label for="phone">Téléphone</label>
              <input
                class="form-input"
                id="phone"
                name="phone"
                type="tel"
                placeholder="Numéro de téléphone"
                v-model="formData.phoneNumber"
                @input="() => (phoneAlreadyUsed = false)"
              />
              <span v-if="$v.phone?.$error"> {{ $v.phone?.$errors[0].$message }} </span>
              <span v-if="phoneAlreadyUsed">Ce numéro est déjà utilisé</span>
            </div>
          </div>

          <div class="mb-4">
            <label for="password">Mot de passe</label>
            <input
              class="form-input"
              id="password"
              name="password"
              type="password"
              placeholder="******************"
              v-model="formData.password"
              @input="() => (incorrectPassword = false)"
            />
            <span v-if="$v.password?.$error"> {{ $v.password?.$errors[0].$message }} </span>
            <span v-if="incorrectPassword">Mot de passe incorrect</span>
          </div>

          <!-- ... D'autres champs de création ... -->

          <input type="submit" class="btn-primary w-full" value="Modifier le compte" />
        </div>
        <div v-else>
          <EditPersonalSkeleton />
        </div>
      </form>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useAPI } from '@/stores/api'
import { useHeader } from '@/stores/header'
import useVuelidate from '@vuelidate/core'
import { helpers } from '@vuelidate/validators'
import { ref, watch } from 'vue'
import SegmentedControl from '@/components/SegmentedControl.vue'
import SegmentedElement from '@/components/SegmentedElement.vue'
import AlertInfo from '@/components/AlertInfo.vue'
import EditPersonalSkeleton from '@/components/skeletons/EditPersonalSkeleton.vue'

const incorrectPassword = ref(false)
const emailAlreadyUsed = ref(false)
const phoneAlreadyUsed = ref(false)
const modified = ref(false)
const url = ref(useHeader().user?.photo)
const loading = ref(true)

watch(useHeader(), (header) => {
  url.value = header.user?.photo
})

const submitForm = async () => {
  const isFormCorrect = await $v.value.$validate()
  if (!isFormCorrect) return
  if (formData.value.profilePicture) {
    const reader = new FileReader()
    reader.readAsDataURL(formData.value.profilePicture)
    reader.onloadend = () => {
      editUser(btoa(reader.result as string))
    }
  } else {
    editUser(null)
  }
}

function editUser(profilePicture: string | ArrayBuffer | null) {
  modified.value = false
  useAPI()
    .instance.put('/users', {
      firstName: formData.value.firstName,
      lastName: formData.value.lastName,
      email: formData.value.email,
      phoneNumber: formData.value.phoneNumber,
      password: formData.value.password,
      profilePicture: profilePicture
    })
    .catch((e: any) => {
      if (e.response.status == 400) {
        incorrectPassword.value = true
      }
      if (e.response.status != 409) {
        return
      }
      if (e.response.data.message.startsWith('Phone')) {
        phoneAlreadyUsed.value = true
      } else {
        emailAlreadyUsed.value = true
      }
    })
    .then((response) => {
      if (!response) return
      useHeader().updateUserDetails(response.data)
      modified.value = true
      formData.value.password = ''
      $v = useVuelidate(rules, formData)
    })
}

useAPI()
  .instance.get('/users')
  .then((response) => {
    formData.value = response.data
    if (formData.value.profilePicture) {
      fetch(atob(formData.value.profilePicture as any)).then(async (res) => {
        formData.value.profilePicture = await res.blob()
      })
    }
    loading.value = false
  })

const formData = ref({
  firstName: '',
  lastName: '',
  email: '',
  phoneNumber: '',
  password: '',
  profilePicture: new Blob()
})

const rules = {
  firstName: {
    required: helpers.withMessage('Champ obligatoire', (value: string) => !!value.trim())
  },
  lastName: {
    required: helpers.withMessage('Champ obligatoire', (value: string) => !!value.trim())
  },
  email: {
    required: helpers.withMessage('Champ obligatoire', (value: string) => !!value.trim()),
    email: helpers.withMessage('Format e-mail invalide', (value: string) =>
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)
    )
  },
  phoneNumber: {
    required: helpers.withMessage('Champ obligatoire', (value: string) => !!value.trim()),
    phoneNumber: helpers.withMessage('Format invalide', (value: string) =>
      /^(?:(?:\+|00)33|0)\s*[1-9](?:[\s.-]*\d{2}){4}$/.test(value)
    )
  },
  password: {
    required: helpers.withMessage('Champ obligatoire', (value: string) => !!value.trim())
  }
}

function onFileChange(e: any) {
  formData.value.profilePicture = e.target.files[0]
  url.value = URL.createObjectURL(formData.value.profilePicture)
}

let $v = useVuelidate(rules, formData)
</script>
