<script setup lang="ts"></script>
<template>
  <div class="flex grow flex-col items-center justify-center gap-8">
    <div>
      <h1 class="text-center text-9xl font-bold">404</h1>
      <p class="text-center text-3xl font-bold">Page introuvable</p>
    </div>

    <p class="text-center">
      La page que vous recherchez a peut-être été supprimée, <br />a changé de nom ou n'est pas
      disponible.
    </p>

    <router-link to="/" class="btn btn-primary w-fit">Retourner sur la page principale</router-link>
  </div>
</template>
