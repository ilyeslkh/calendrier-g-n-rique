<script setup lang="ts">
import { reactive, ref, type Ref } from 'vue'
import {
  updateSlotsOptions,
  type Slot,
  updateSlotSelection,
  getEndHours
} from '@/utils/TimeSlotUtils'
import useVuelidate from '@vuelidate/core'
import { helpers, required } from '@vuelidate/validators'
import { Plus } from 'lucide-vue-next'
import { Minus } from 'lucide-vue-next'
import { Copy } from 'lucide-vue-next'

const props = defineProps(['onSubmit'])
const weekDays = ref(['Lun.', 'Mar.', 'Mer.', 'Jeu.', 'Ven.', 'Sam.', 'Dim.'])
let startHours: Ref<string[]> = ref([])
let endHours: Ref<string[]> = ref([])

const formData = reactive({
  slotDuration: 1,
  durationUnit: 'hours',
  nbPersonMax: 1,
  planning: [] as Slot[][]
})

const rules = {
  slotDuration: {
    toLarge: helpers.withMessage('Durée trop grande', (s: number) => {
      if (formData.durationUnit == 'hours') {
        return s < 24
      }
      return s < 60
    })
  },
  durationUnit: { required: helpers.withMessage('Champ obligatoire', required) },
  nbPersonMax: { required: helpers.withMessage('Champ obligatoire', required) },
  planning: {
    noOverlap: helpers.withMessage('Les horaires ne doivent pas se chevaucher', (p: Slot[][]) => {
      return p.every((slots) =>
        slots.every((value, slotIndex) => {
          if (slotIndex == 0) return true
          const previous = slots[slotIndex - 1]
          return previous.end <= value.start
        })
      )
    })
  }
}

const $v = useVuelidate(rules, formData)

const submitForm = async () => {
  const isFormCorrect = await $v.value.$validate()
  if (!isFormCorrect) return
  const coeff = formData.durationUnit == 'minutes' ? 1 : 60
  props.onSubmit({
    slotDuration: formData.slotDuration * coeff,
    nbPersonMax: formData.nbPersonMax,
    planning: formData.planning
  })
}

function updateInterval() {
  updateSlotsOptions(startHours.value, endHours.value, getSlotDurationMinutes())

  formData.planning.forEach((slots) =>
    slots.forEach((slot) => {
      updateSlotSelection(startHours.value, endHours.value, slot, getSlotDurationMinutes())
    })
  )
}

function initHours() {
  formData.planning = []
  for (let i = 0; i < weekDays.value.length; i++) {
    formData.planning.push([
      {
        start: '09:00',
        end: '17:00'
      }
    ])
  }
}

function updateSlotDuration() {
  updateInterval()
}

function getSlotDurationMinutes() {
  const coeff = formData.durationUnit == 'minutes' ? 1 : 60
  return coeff * formData.slotDuration
}

function addSlot(weekIndex: number) {
  formData.planning[weekIndex].push({
    start: '09:00',
    end: '17:00'
  })
}

function removeSlot(weekIndex: number, slotIndex: number) {
  formData.planning[weekIndex].splice(slotIndex, 1)
}

function copyToAll(weekIndex: number) {
  const toCopy = formData.planning[weekIndex]
  for (let i = 0; i < formData.planning.length; i++) {
    if (formData.planning[i].length) {
      formData.planning[i] = toCopy.map((copy) => {
        return { start: copy.start, end: copy.end }
      })
    }
  }
}

updateInterval()
initHours()
</script>

<template>
  <form @submit.prevent="submitForm" novalidate>
    <label for="slot-duration">Durée des rendez-vous</label>
    <div class="mb-6">
      <div class="flex gap-2">
        <input
          id="slot-duration"
          class="form-input"
          type="number"
          :min="1"
          step="1"
          v-model.number="formData.slotDuration"
          @change="updateSlotDuration()"
        />
        <select id="unit" v-model="formData.durationUnit" @change="updateSlotDuration()">
          <option value="minutes">minute(s)</option>
          <option value="hours" selected>heure(s)</option>
        </select>
      </div>
      <span v-if="$v.slotDuration.$error"> {{ $v.slotDuration.$errors[0].$message }} </span>
      <span v-if="$v.durationUnit.$error"> {{ $v.durationUnit.$errors[0].$message }} </span>
    </div>

    <label for="nb-person-max">Nombre maximal de personnes</label>
    <div class="mb-6 flex gap-2">
      <input
        id="slot-duration"
        class="form-input"
        type="number"
        :min="1"
        step="1"
        v-model.number="formData.nbPersonMax"
      />
    </div>
    <span v-if="$v.nbPersonMax.$error"> {{ $v.nbPersonMax.$errors[0].$message }} </span>

    <div class="mb-6">
      <label>Planning</label>
      <div v-for="(weekDay, weekIndex) of weekDays" :key="weekDay" class="mb-2 flex gap-2">
        <p class="mt-2 w-8">{{ weekDay }}</p>
        <div class="flex flex-col gap-2" v-if="formData.planning[weekIndex].length">
          <div
            v-for="(slot, slotIndex) of formData.planning[weekIndex]"
            :key="slotIndex"
            class="flex items-center justify-start gap-2"
          >
            <select class="w-32" id="start" v-model="slot.start">
              <option v-for="hour of startHours" :key="hour">
                {{ hour }}
              </option>
            </select>
            <select class="w-32" id="end" v-model="slot.end">
              <option
                v-for="hour of getEndHours(slot, endHours, getSlotDurationMinutes())"
                :key="hour"
              >
                {{ hour }}
              </option>
            </select>
            <Plus @click="addSlot(weekIndex)" />
            <Minus @click="removeSlot(weekIndex, slotIndex)" />
            <Copy @click="copyToAll(weekIndex)" v-if="slotIndex == 0" />
          </div>
        </div>
        <div v-else class="mt-2 flex">
          <p @click="addSlot(weekIndex)" class="underline">Ajouter un créneau</p>
        </div>
      </div>
      <span v-if="$v.planning.$error"> {{ $v.planning.$errors[0].$message }} </span>
    </div>

    <input type="submit" class="btn-primary" value="Valider" />
  </form>
</template>
