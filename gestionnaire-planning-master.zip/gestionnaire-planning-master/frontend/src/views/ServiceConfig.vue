<script setup lang="ts">
import useVuelidate from '@vuelidate/core'
import { helpers, required } from '@vuelidate/validators'
import { reactive, ref } from 'vue'

const props = defineProps(['onSubmit', 'response'])
const url = ref('')

function onFileChange(e: any) {
  formData.logo = e.target.files[0]
  url.value = URL.createObjectURL(formData.logo)
}

const formData = reactive({
  name: '',
  logo: new Blob()
})

const rules = {
  name: { required: helpers.withMessage('Champ obligatoire', required) },
  logo: {
    required: helpers.withMessage('Vous devez ajouter une image!', (value: Blob) => {
      return value.size > 0
    })
  }
}

const $v = useVuelidate(rules, formData)

const submitForm = async () => {
  const isFormCorrect = await $v.value.$validate()
  if (!isFormCorrect) return
  props.onSubmit(formData)
}
</script>

<template>
  <div class="flex flex-col items-center justify-center">
    <form @submit.prevent="submitForm" class="w-full max-w-lg" novalidate>
      <div class="mb-6">
        <label for="name">Nom de l'instance</label>
        <input
          class="form-input"
          id="name"
          name="name"
          type="text"
          placeholder="ex: Cabinet de M. Dupont"
          v-model="formData.name"
        />
        <span v-if="$v.name.$error"> {{ $v.name.$errors[0].$message }} </span>
      </div>

      <label for="logo">Logo</label>
      <div class="mb-6">
        <div
          class="relative flex cursor-pointer flex-col rounded border-2 border-dashed border-gray-300 bg-gray-50 text-gray-400"
        >
          <input
            id="logo"
            accept="image/*"
            type="file"
            multiple
            class="absolute inset-0 z-50 m-0 h-full w-full cursor-pointer p-0 opacity-0 outline-none"
            title=""
            @change="onFileChange"
          />

          <div class="flex flex-col items-center justify-center py-10 text-center">
            <svg
              class="text-current-50 mr-1 h-6 w-6"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
              />
            </svg>
            <p class="m-0">Drag your files here or click in this area.</p>
          </div>
        </div>
        <span v-if="$v.logo.$error"> {{ $v.logo.$errors[0].$message }} </span>
      </div>

      <div v-if="url" class="mb-6">
        <label for="preview">Aperçu</label>
        <div class="flex justify-center rounded-md bg-gray-200 p-5">
          <div
            id="preview"
            class="h-32 w-32 rounded bg-white bg-cover bg-center bg-no-repeat shadow"
            :style="'background-image: url(\'' + url + '\')'"
          ></div>
        </div>
      </div>
      <input type="submit" class="btn-primary" value="Étape suivante" />
    </form>
  </div>
</template>
