<template>
  <div class="mt-8 flex grow flex-col items-center">
    <SegmentedControl>
      <SegmentedElement link="/next-meetings" name="Réservations courantes"></SegmentedElement>
      <SegmentedElement link="/previous-meetings" name="Réservations passées"></SegmentedElement>
    </SegmentedControl>
    <meetings-list :reservations="reservations" :sort-descending="false" v-show="!loading" />
    <MeetingsSkeleton v-if="loading" />
  </div>
</template>

<script setup lang="ts">
import { onBeforeMount, ref } from 'vue'
import { useAPI } from '@/stores/api'
import type { Reservation } from '@/components/MeetingsList.vue'
import MeetingsList from '@/components/MeetingsList.vue'
import SegmentedControl from '@/components/SegmentedControl.vue'
import SegmentedElement from '@/components/SegmentedElement.vue'
import MeetingsSkeleton from '@/components/skeletons/MeetingsSkeleton.vue'
import { useToken } from '@/stores/token'
import router from '@/router'

const loading = ref(true)

const reservations = ref<{ [key: string]: Reservation[] }>({})

onBeforeMount(() => {
  if (!useToken().isConnected()) {
    router.replace({
      path: '/login',
      query: { redirect: window.location.pathname, automatic: '' }
    })
    return
  }

  useAPI()
    .instance.get('/reservations?filter=current')
    .then((response) => {
      loading.value = false
      reservations.value = response.data
    })
})
</script>
