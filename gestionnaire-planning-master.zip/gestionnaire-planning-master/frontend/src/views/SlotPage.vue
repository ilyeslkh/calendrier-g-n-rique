<script setup lang="ts">
import { computeSlotEnd, parseYearMonthAndDay } from '@/utils/TimeSlotUtils'
import { useRoute } from 'vue-router'
import { onMounted, ref, type Ref } from 'vue'
import DayTitle from '@/components/DayTitle.vue'
import moment from 'moment'
import { useAPI } from '@/stores/api'
import { useConfigStore } from '@/stores/config'
import { useToken } from '@/stores/token'
import CancelledBadge from '@/components/CancelledBadge.vue'
import ModalWindow from '@/components/ModalWindow.vue'
import SlotSkeleton from '@/components/skeletons/SlotSkeleton.vue'
import router from '@/router'

interface TimeSlot {
  id: number
  nbPersons: number
  responseType: string
  customInfo: any
  cancelled: boolean
  cancelReason: undefined | string
}

const selectedDay = ref(new Date())
const selectedSlot = ref('')
const slotEnd = ref('')
const nbPersons = ref(1)

const nbAvailable = ref(0)

const timeSlotToCancel: Ref<boolean> = ref(false)
const reservationToCancel: Ref<Number | undefined> = ref(undefined)
const cancelReason = ref('')

const loading = ref(true)

const timeslot: Ref<TimeSlot> = ref({
  id: 0,
  nbPersons: 0,
  responseType: '',
  customInfo: {},
  cancelled: false,
  cancelReason: undefined
})

onMounted(() => {
  const route = useRoute()
  selectedDay.value = parseYearMonthAndDay()
  selectedSlot.value = route.query.startHour?.toString() || ''
  slotEnd.value = computeSlotEnd(selectedSlot.value)
  getTimeSlotInfos()
})

function getTimeSlotInfos() {
  useAPI()
    .instance.get(
      `/timeslots/${selectedDay.value.getFullYear()}/${
        selectedDay.value.getMonth() + 1
      }/${selectedDay.value.getDate()}/${selectedSlot.value}`
    )
    .then((res: any) => {
      timeslot.value = res.data
      nbAvailable.value = useConfigStore().nbPersonMax - timeslot.value.nbPersons
      timeslot.value.customInfo?.reservations?.map((reservation: any) => {
        reservation.nbPersonsModif = reservation.nbPersons
      })
      loading.value = false
    })
}

function makeReservation() {
  if (!useToken().isConnected()) {
    router.replace({
      path: '/login',
      query: { redirect: window.location.pathname + window.location.search, automatic: '' }
    })
    return
  }
  useAPI()
    .instance.post('/reservations', {
      nbPersons: nbPersons.value,
      date: moment(selectedDay.value).format('yyyy-MM-DD'),
      startHour: selectedSlot.value
    })
    .then((res: any) => {
      if (timeslot.value.responseType == 'NOT_RESERVED') {
        timeslot.value.responseType = 'RESERVED'
        timeslot.value.customInfo = { reservations: [] }
      }
      res.data.nbPersonsModif = res.data.nbPersons
      timeslot.value.customInfo.reservations.push(res.data)
      nbAvailable.value -= res.data.nbPersons
    })
}

function cancelTimeSlot() {
  useAPI()
    .instance.patch(
      `/timeslots/${selectedDay.value.getFullYear()}/${
        selectedDay.value.getMonth() + 1
      }/${selectedDay.value.getDate()}/${selectedSlot.value}`,
      {
        cancelled: true,
        cancelReason: cancelReason.value
      }
    )
    .then((result) => {
      timeslot.value = result.data
    })
  timeSlotToCancel.value = false
}

function updateNbPersons(idx: number) {
  let reservation = timeslot.value.customInfo.reservations[idx]
  useAPI()
    .instance.patch(`/reservations/${reservation.id}`, {
      nbPersons: reservation.nbPersonsModif
    })
    .then((result) => {
      nbAvailable.value -= reservation.nbPersonsModif - reservation.nbPersons
      result.data.nbPersonsModif = result.data.nbPersons
      timeslot.value.customInfo.reservations[idx] = result.data
    })
}

function cancelReservation(idx: number) {
  let reservation = timeslot.value.customInfo.reservations[idx]
  useAPI()
    .instance.patch(`/reservations/${reservation.id}`, {
      cancelled: true,
      cancelReason: cancelReason.value
    })
    .then((result) => {
      nbAvailable.value += reservation.nbPersons
      timeslot.value.customInfo.reservations[idx] = result.data
    })
  reservationToCancel.value = undefined
}

function canMakeReservation() {
  const tokenStore = useToken()

  return (
    !tokenStore.isAdmin() &&
    nbAvailable.value &&
    (timeslot.value.responseType == 'NOT_RESERVED' ||
      timeslot.value.customInfo?.reservations?.every((r: any) => r.cancelled)) &&
    !isTimeSlotLate()
  )
}

function isTimeSlotLate() {
  const date = new Date(selectedDay.value)
  const hours = moment(selectedSlot.value, 'HH:mm:SS').toDate()
  date.setHours(hours.getHours(), hours.getMinutes(), hours.getSeconds())
  return date < new Date()
}
</script>

<template>
  <div class="mb-8 mt-8 flex grow items-center justify-center" v-show="!loading">
    <div class="max-w-24">
      <div class="flex items-center">
        <day-title :day="selectedDay"></day-title>
        <div class="ml-2 rounded-xl bg-primary p-1 px-3">
          <p class="text-white">{{ selectedSlot }} - {{ slotEnd }}</p>
        </div>
      </div>

      <p v-if="!timeslot.cancelled"><strong>Places disponibles:</strong> {{ nbAvailable }}</p>
      <p class="flex items-center gap-2 pb-1 pt-1">
        <strong>Statut:</strong> <CancelledBadge class="w-fit" :cancelled="timeslot.cancelled" />
      </p>
      <p v-if="timeslot.cancelReason" class="w-96 overflow-hidden text-ellipsis">
        <strong>Raison de l'annulation:</strong> {{ timeslot.cancelReason }}
      </p>
      <div v-if="canMakeReservation()" class="pt-3">
        <form @submit.prevent="makeReservation()">
          <label for="nb-person">Nombre de personnes</label>
          <div class="pb-3">
            <input
              id="slot-duration"
              class="form-input"
              type="number"
              :min="1"
              step="1"
              :max="nbAvailable"
              v-model.number="nbPersons"
            />
          </div>
          <input type="submit" class="btn-primary w-full" value="Confirmer la réservation" />
        </form>
      </div>

      <div v-if="useToken().isAdmin() && !isTimeSlotLate()">
        <form @submit.prevent="() => (timeSlotToCancel = true)" v-if="!timeslot.cancelled">
          <input type="submit" class="btn-primary w-full" value="Annuler le créneau" />
        </form>
      </div>

      <div v-if="timeslot.responseType != 'NOT_RESERVED'">
        <h1 class="my-3 text-xl font-bold">Réservations</h1>
        <div class="flex flex-col gap-3">
          <div
            v-for="(reservation, idx) of timeslot.customInfo.reservations"
            v-bind:key="reservation.id"
            class="rounded-lg border border-gray-300 p-5 shadow"
          >
            <p>
              <strong>{{ reservation.user.firstName }} {{ reservation.user.lastName }}</strong> -
              <a class="text-blue-500" :href="'mailto:' + reservation.user.email">{{
                reservation.user.email
              }}</a>
            </p>
            <div class="align-center flex gap-2">
              <p class="self-center text-center font-bold">Places réservées:</p>
              <div>
                <p v-if="reservation.cancelled">
                  <strong>{{ reservation.nbPersons }}</strong>
                </p>
                <input
                  v-else
                  id="slot-duration"
                  class="form-input h-8 w-10"
                  type="number"
                  :min="1"
                  step="1"
                  :max="nbAvailable + reservation.nbPersons"
                  v-model.number="reservation.nbPersonsModif"
                />
              </div>
            </div>
            <p class="flex items-center gap-2">
              <strong>Statut:</strong> <CancelledBadge :cancelled="reservation.cancelled" />
            </p>
            <p v-if="reservation.cancelReason" class="w-96 overflow-hidden text-ellipsis">
              <strong>Raison de l'annulation:</strong> {{ reservation.cancelReason }}
            </p>
            <div class="flex gap-2" v-if="!reservation.cancelled && !isTimeSlotLate()">
              <button @click.prevent="updateNbPersons(idx)" class="btn-secondary mt-1 block w-full">
                Modifier
              </button>
              <button
                @click.prevent="reservationToCancel = idx"
                class="btn-primary mt-1 block w-full"
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <ModalWindow
      title="Annulation d'une réservation"
      :onClose="() => (reservationToCancel = undefined)"
      v-if="reservationToCancel != undefined"
    >
      <h1 class="mb-2">Pourquoi voulez-vous annuler cette réservation? (optionnel)</h1>
      <textarea
        class="form-input mb-2"
        placeholder="Saisissez la raison de votre annulation..."
        v-model="cancelReason"
      ></textarea>
      <div class="flex gap-2">
        <button
          class="btn-secondary w-full"
          @click.prevent="() => (reservationToCancel = undefined)"
        >
          Revenir en arrière
        </button>
        <button
          class="btn-primary w-full"
          @click.prevent="cancelReservation(reservationToCancel as number)"
        >
          Annuler la réservation
        </button>
      </div>
    </ModalWindow>
    <ModalWindow
      title="Annulation d'un créneau"
      :onClose="() => (timeSlotToCancel = false)"
      v-if="timeSlotToCancel"
    >
      <h1 class="mb-2">Pourquoi voulez-vous annuler ce créneau? (optionnel)</h1>
      <textarea
        class="form-input mb-2"
        placeholder="Saisissez la raison de votre annulation..."
        v-model="cancelReason"
      ></textarea>
      <div class="flex gap-2">
        <button class="btn-secondary w-full" @click.prevent="() => (timeSlotToCancel = false)">
          Revenir en arrière
        </button>
        <button class="btn-primary w-full" @click.prevent="cancelTimeSlot()">
          Annuler la réservation
        </button>
      </div>
    </ModalWindow>
  </div>
  <SlotSkeleton v-if="loading" />
</template>
