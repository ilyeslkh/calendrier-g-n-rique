<script setup lang="ts">
import { onMounted, ref, type Ref } from 'vue'
import { useAPI } from '@/stores/api'
import moment from 'moment'
import { parseYearMonthAndDay } from '@/utils/TimeSlotUtils'
import DayTitle from '@/components/DayTitle.vue'
import { useConfigStore } from '@/stores/config'

interface Slot {
  startHour: Date
  isCancelled: boolean
  nbPersons: number
}

let selectedDay: Ref<Date> = ref(new Date())
let slots: Ref<Slot[]> = ref([])

function getGradientColor(slot: Slot, percent: number) {
  if (slot.isCancelled) {
    return `hsl(0, 0%, ${percent}%)`
  }
  const percentage = slot.nbPersons / useConfigStore().nbPersonMax
  var hue = ((1 - percentage) * 120).toString(10)
  return `hsl(${hue},100%,${percent}%)`
}

function updateSlots() {
  const year = selectedDay.value.getFullYear()
  const month = selectedDay.value.getMonth()
  const day = selectedDay.value.getDate()
  useAPI()
    .instance.get(`/timeslots/${year}/${month + 1}/${day}`)
    .then(({ data }) => {
      data.forEach((slot: any) => {
        const date = new Date(year, month, day)
        date.setHours(slot.startHour.split(':')[0])
        date.setMinutes(slot.startHour.split(':')[1])
        slot.startHour = date
      })
      slots.value = data
    })
}

onMounted(() => {
  selectedDay.value = parseYearMonthAndDay()
  updateSlots()
})
</script>

<template>
  <div class="p-5">
    <day-title class="pb-4" :day="selectedDay"></day-title>

    <div class="flex flex-wrap gap-4">
      <router-link
        :to="
          '/slot?year=' +
          selectedDay.getFullYear() +
          '&month=' +
          (selectedDay.getMonth() + 1) +
          '&day=' +
          selectedDay.getDate() +
          '&startHour=' +
          moment(slot.startHour).format('HH:mm')
        "
        v-for="slot of slots"
        v-bind:key="slot.startHour.getTime()"
        class="w-20 rounded py-2 text-center shadow"
        :style="
          'border-left: 10px solid ' +
          getGradientColor(slot, 70) +
          '; background-color: ' +
          getGradientColor(slot, 97)
        "
      >
        {{ moment(slot.startHour).format('HH:mm') }}
      </router-link>
    </div>
  </div>
</template>
