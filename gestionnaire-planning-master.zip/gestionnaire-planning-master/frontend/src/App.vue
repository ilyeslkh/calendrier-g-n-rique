<script setup lang="ts">
import { RouterView } from 'vue-router'
import { onBeforeMount, ref } from 'vue'
import AppHeader from './views/AppHeader.vue'
import { useConfigStore } from './stores/config'
import { useToken } from './stores/token'
import { useAPI } from './stores/api'

const loading = ref(true)

onBeforeMount(async () => {
  useAPI().initErrorInterceptor()
  useToken().updateLogin()
  await useConfigStore().getConfig()
  loading.value = false
})
</script>

<template>
  <AppHeader v-if="$route.path != '/first-config'" />

  <RouterView v-if="!loading" />
</template>
