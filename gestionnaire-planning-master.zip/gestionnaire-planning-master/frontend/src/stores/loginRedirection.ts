import { defineStore } from "pinia";

export const loginRedirection = defineStore('loginRedirection', {
    state: () => ({
        link: String,
        message: String
    })
});