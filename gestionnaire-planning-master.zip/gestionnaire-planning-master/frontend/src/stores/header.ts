import { defineStore } from 'pinia'
import { useAPI } from '@/stores/api'
import { useToken } from './token'
import { createAvatar } from '@dicebear/core'
import { thumbs } from '@dicebear/collection'

interface Header {
  nom: string
  prenom: String
  photo: Blob | string // Assuming logo is a URL or some string identifier
  // Add other user properties as needed
  email: string
}

export const useHeader = defineStore('user', {
  state: () => ({
    user: null as Header | null,
    loading: false
  }),

  actions: {
    fetchUserDetails() {
      if (useToken().isConnected()) {
        this.loading = true
        // Use the API instance to make requests
        useAPI().instance.get('/users')
        .catch((error) => {
          // Si l'utilisateur n'existe plus on le déconnecte
          if (error.response.status === 404) {
            useToken().disconnect()
          }
        })
        .then((response) => {
          if (!response) return;
          this.updateUserDetails(response.data)
          this.loading = false
        })
      } else {
        this.user = null;
        this.loading = false;
      }
    },

    updateUserDetails(user: any) {
      let photo;
      if (!user.profilePicture) {
        photo = createAvatar(thumbs, {
          size: 128,
          seed: user.email,
          scale: 60
        }).toDataUriSync()
      } else {
        photo = atob(user.profilePicture)
      }

      // Update user state with the received user details
      this.user = {
        nom: user.lastName,
        prenom: user.firstName,
        photo: photo,
        email: user.email
      }
    }
  }
})
