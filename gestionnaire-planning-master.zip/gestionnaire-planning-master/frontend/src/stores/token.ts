import { defineStore } from 'pinia'
import { useAPI } from './api'
import { useHeader } from './header'

export const useToken = defineStore('token', {
  state: () => ({
    token: '',
    role: '',
    expired: false
  }),
  actions: {
    async login(email: string, password: string) {
      try {
        const response = await useAPI().instance.post(
          '/users/token',
          {},
          {
            auth: {
              username: email,
              password: password
            }
          }
        )
        localStorage.setItem('token', response.data)
        this.updateLogin()
        return true
      } catch {
        return false
      }
    },

    async updateLogin() {
      const token = localStorage.getItem('token')
      if (token) {
        this.expired = false
        this.token = token
        useAPI().instance.defaults.headers['Authorization'] = 'Bearer ' + this.token
        this.updateTokenInfos()
        useHeader().fetchUserDetails()
      }
    },

    updateTokenInfos() {
      const payload = this.parseJwt()
      this.role = payload.scope
    },

    parseJwt() {
      const base64Url = this.token.split('.')[1]
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/')
      const jsonPayload = decodeURIComponent(
        window
          .atob(base64)
          .split('')
          .map(function (c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)
          })
          .join('')
      )

      return JSON.parse(jsonPayload)
    },

    isAdmin() {
      return this.role == 'ADMIN'
    },

    disconnect() {
      localStorage.removeItem('token')
      this.token = ''
      this.role = ''
      useAPI().instance.defaults.headers['Authorization'] = ''
      this.expired = false
    },

    isConnected() {
      return this.token != ''
    }
  }
})
