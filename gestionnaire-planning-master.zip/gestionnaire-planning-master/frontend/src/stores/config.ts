import { defineStore } from 'pinia'
import { useAPI } from './api'
import router from '@/router'

export const useConfigStore = defineStore('config', {
  state: () => ({
    nbPersonMax: 0,
    slotDuration: 0,
    name: '',
    logo: '',
    loading: true
  }),
  actions: {
    async getConfig() {
      this.loading = true
      await useAPI()
        .instance.get('/config')
        .catch((e) => {
          if (e.response.status == 404) {
            router.push({ path: '/first-config' })
          }
        })
        .then((response: any) => {
          if (!response) return
          this.nbPersonMax = response.data.nbPersonMax
          this.slotDuration = response.data.slotDuration
          this.name = response.data.name
          this.logo = atob(response.data.logo)
          this.loading = false
        })
    },
    async setConfig(
      name: string,
      logo: string | ArrayBuffer | null,
      slotDuration: number,
      nbPersonMax: number,
      planning: { day: number; start: string; end: string }[]
    ) {
      const response = await useAPI().instance.post('/config', {
        name: name,
        logo: logo,
        slotDuration: slotDuration,
        nbPersonMax: nbPersonMax,
        planning: planning
      })

      // Mettre à jour les propriétés de l'état avec les nouvelles valeurs si la requête réussit
      this.nbPersonMax = response.data.nbPersonMax
      this.slotDuration = response.data.slotDuration
      this.name = response.data.name
      this.logo = response.data.logo
      this.loading = false
    }
  }
})
