import router from '@/router'
import axios from 'axios'
import { defineStore } from 'pinia'
import { useToken } from './token'

const BASE_URL = 'http://localhost:8080'

export const useAPI = defineStore('api', {
  state: () => ({
    instance: axios.create({
      baseURL: BASE_URL
    })
  }),
  actions: {
    initErrorInterceptor() {
      this.instance.interceptors.response.use(function (response) {
        return response
      }, function (error) {
        if (error.response.status === 401) {
          useToken().expired = true
          router.push({ path: '/login' })
        }
        return Promise.reject(error)
      })
    }
  }
})
