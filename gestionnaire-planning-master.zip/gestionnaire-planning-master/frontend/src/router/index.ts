/// <reference types="vite/client" />
import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'Calendrier',
      component: () => import('@/views/MainCalendar.vue')
    },
    {
      path: '/previous-meetings',
      name: 'Historique des rendez-vous',
      component: () => import('@/views/PreviousMeetings.vue')
    },
    {
      path: '/next-meetings',
      name: 'Prochains rendez-vous',
      component: () => import('@/views/NextMeetings.vue')
    },
    {
      path: '/first-config',
      name: "Configuration de l'application",
      component: () => import('@/views/FirstConfig.vue')
    },
    {
      path: '/day',
      name: 'Vue du jour',
      component: () => import('@/views/DaySlots.vue')
    },

    {
      path: '/login',
      name: 'Page de connexion',
      component: () => import('@/views/LoginPage.vue')
    },
    {
      path: '/slot',
      name: 'Vue du créneau',
      component: () => import('@/views/SlotPage.vue')
    },
    {
      path: '/account/personal-infos',
      name: 'modification',
      component: () => import('../views/EditPersonalInfos.vue')
    },
    {
      path: '/account/security',
      name: 'Sécurité du compte',
      component: () => import('../views/EditSecurity.vue')
    },
    {
      path: '/register',
      name: 'Créer un compte',
      component: () => import('../views/CreateAccount.vue')
    },

    {
      path: '/add',
      name: 'Ajouter un créneau',
      component: () => import('../views/AddSlot.vue')
    },
    {
      path: '/confirmation',
      name: 'Valider son compte',
      component: () => import('../views/ConfirmationPage.vue')
    },
    {
      path: '/:pathMatch(.*)*', 
      name: 'Erreur 404',
      component: () => import('../views/404Page.vue'),
    },
    {
      path: '/403',
      name: 'Erreur 403',
      component: () => import('../views/403Page.vue')
    }
  ]
})

export default router
