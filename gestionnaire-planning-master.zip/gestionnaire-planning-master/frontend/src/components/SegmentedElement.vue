<script setup lang="ts">
defineProps(['link', 'name'])
</script>
<template>
  <router-link
    :to="link"
    type="button"
    class="text-md border bg-transparent px-4 py-2 font-medium text-gray-900 hover:bg-gray-200 focus:z-10 focus:ring-2 focus:ring-gray-500"
  >
    {{ name }}
  </router-link>
</template>
