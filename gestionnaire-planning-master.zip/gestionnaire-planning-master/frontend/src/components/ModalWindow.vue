<script setup lang="ts">
import { X } from 'lucide-vue-next'

defineProps(['title', 'onClose'])
</script>
<template>
  <div
    class="fixed bottom-0 left-0 right-0 top-0 flex h-full w-full items-center justify-center bg-[rgba(0,0,0,0.2)]"
  >
    <div class="h-fit w-[32em] rounded bg-gray-100 p-4 shadow-md">
      <div class="mb-2 flex justify-between">
        <h1 class="text-lg font-bold">{{ title }}</h1>
        <button @click="onClose"><X /></button>
      </div>
      <slot></slot>
    </div>
  </div>
</template>
