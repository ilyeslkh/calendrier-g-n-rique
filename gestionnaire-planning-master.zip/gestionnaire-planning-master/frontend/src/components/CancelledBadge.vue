<script setup lang="ts">
defineProps(['cancelled'])
</script>

<template>
  <div
    class="rounded-lg px-3 py-1"
    :class="cancelled ? 'bg-red-400 text-red-900' : 'bg-green-400 text-green-900'"
  >
    {{ cancelled ? 'Annulée' : 'Valide' }}
  </div>
</template>
