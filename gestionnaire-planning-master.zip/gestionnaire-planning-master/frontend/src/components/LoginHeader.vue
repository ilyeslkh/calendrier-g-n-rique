<script setup lang="ts">
import { ref } from 'vue'
import { useToken } from '@/stores/token'
import { useHeader } from '@/stores/header'
import ProfileSkeleton from './skeletons/ProfileSkeleton.vue'
const showDropdown = ref(false)
</script>

<template>
  <div v-show="!useHeader().loading">
    <div
      v-if="useToken().isConnected()"
      @click="showDropdown = !showDropdown"
      class="relative flex min-w-[170px] flex-col items-center"
    >
      <div
        class="flex items-center gap-2 rounded-2xl px-2 py-1 hover:cursor-pointer hover:bg-gray-200"
      >
        <div
          class="h-8 w-8 rounded-full bg-white bg-cover bg-center bg-no-repeat shadow"
          :style="'background-image: url(\'' + useHeader().user?.photo + '\')'"
        ></div>
        <span class="max-w-[170px] select-none overflow-hidden text-ellipsis whitespace-nowrap"
          >{{ useHeader().user?.prenom }} {{ useHeader().user?.nom }}</span
        >
      </div>

      <div v-if="showDropdown" class="dropdown-menu flex flex-col gap-3">
        <router-link
          to="/account/personal-infos"
          class="block rounded-2xl px-3 py-2 text-center text-black hover:bg-gray-200"
          >Modifier le profil</router-link
        >
        <button class="btn-primary w-full" @click="useToken().disconnect">Se déconnecter</button>
      </div>
    </div>
    <div v-else>
      <div class="flex gap-2">
        <router-link to="/register">
          <button type="button" class="rounded-2xl px-3 py-2 hover:bg-gray-200">
            Créer un compte
          </button>
        </router-link>
        <router-link to="/login">
          <input type="submit" class="btn-primary" value="Connexion" />
        </router-link>
      </div>
    </div>
  </div>
  <ProfileSkeleton v-if="useHeader().loading" />
</template>

<style>
.dropdown-menu {
  position: absolute;
  top: 45px; /* Ajuste la distance avec le haut*/
  background-color: rgba(255, 255, 255); /* Fond plus foncé */
  color: white; /* Texte blanc */
  border: 1px solid #ccc;
  border-radius: 10px;
  padding: 15px; /* Plus de marge intérieure pour plus de hauteur */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  z-index: 1000; /* Assure que le menu est au-dessus des autres éléments */
  min-width: 200px; /* Largeur minimale */
}
</style>
