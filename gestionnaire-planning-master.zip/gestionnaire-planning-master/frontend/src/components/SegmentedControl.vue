<template>
  <div class="mb-6 inline-flex rounded-md" role="group" id="segmented-control">
    <slot></slot>
  </div>
</template>
<style>
#segmented-control .router-link-active {
  background-color: rgb(239 68 68 / var(--tw-bg-opacity));
  color: white;
}

#segmented-control .router-link-active:hover {
  background-color: rgb(239 68 68 / var(--tw-bg-opacity));
  color: white;
}

#segmented-control > a:first-child {
  border-top-left-radius: 10px;
  border-bottom-left-radius: 10px;
}

#segmented-control > a:last-child {
  border-top-right-radius: 10px;
  border-bottom-right-radius: 10px;
}
</style>
