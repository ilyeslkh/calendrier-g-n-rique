import { describe, it, expect } from 'vitest'

import { getFirstDayOfCalendar } from '../../views/MainCalendar.vue'

const JANUARY = 0
const AUGUST = 7
const SEPTEMBER = 8
const OCTOBER = 9
const DECEMBER = 11

describe('MainCalendar', () => {
  it('should return the previous month if the beginning of the month is not on monday', () => {
    expect(getFirstDayOfCalendar(SEPTEMBER, 2023)).toStrictEqual(new Date(2023, AUGUST, 28));
  })
  it('should also work with first day of the month being sunday', () => {
    expect(getFirstDayOfCalendar(OCTOBER, 2023)).toStrictEqual(new Date(2023, SEPTEMBER, 25));
  })
  it('should still display previous month when the first day of the current month is monday', () => {
    expect(getFirstDayOfCalendar(JANUARY, 2024)).toStrictEqual(new Date(2023, DECEMBER, 25));
  })
})
