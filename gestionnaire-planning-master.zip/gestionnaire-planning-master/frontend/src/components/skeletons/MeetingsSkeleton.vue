<template>
  <div v-for="i in 3" :key="i" class="animate-pulse">
    <div class="mb-4 mt-2 h-4 w-48 rounded bg-skeleton"></div>
    <div class="mb-10 h-36 w-80 rounded bg-skeleton"></div>
  </div>
</template>
