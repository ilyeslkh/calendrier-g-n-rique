<template>
  <div class="flex animate-pulse items-center gap-2">
    <div class="h-10 w-10 rounded bg-skeleton"></div>
    <div class="h-2 w-24 rounded bg-skeleton"></div>
  </div>
</template>
