<template>
  <div class="mt-4 animate-pulse">
    <div class="mb-4 flex flex-col gap-4">
      <div v-for="i in 2" :key="i">
        <div class="bg-skeleton mb-4 h-2 w-16 rounded"></div>
        <div class="bg-skeleton h-10 rounded"></div>
      </div>
    </div>
    <div class="mb-4 grid grid-cols-2 gap-4">
      <div class="col-span-1">
        <div class="bg-skeleton mb-4 h-2 w-16 rounded"></div>
        <div class="bg-skeleton h-10 rounded"></div>
      </div>
      <div class="col-span-1">
        <div class="bg-skeleton mb-4 h-2 w-16 rounded"></div>
        <div class="bg-skeleton h-10 rounded"></div>
      </div>
    </div>
    <div class="bg-skeleton mb-4 h-2 w-16 rounded"></div>
    <div class="bg-skeleton mb-4 h-10 rounded"></div>

    <div class="bg-skeleton h-10 rounded"></div>
  </div>
</template>
