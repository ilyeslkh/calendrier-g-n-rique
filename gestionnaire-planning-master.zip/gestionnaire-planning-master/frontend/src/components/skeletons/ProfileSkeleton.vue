<template>
  <div class="flex animate-pulse items-center gap-2">
    <div class="h-8 w-8 rounded-full bg-skeleton"></div>
    <div class="h-2 w-24 rounded bg-skeleton"></div>
  </div>
</template>
