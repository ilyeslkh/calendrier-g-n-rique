<template>
  <div class="flex grow animate-pulse items-center justify-center">
    <div class="max-w-24">
      <div class="mb-4 mt-2 h-6 w-96 rounded bg-skeleton"></div>
      <div class="mb-4 mt-2 h-4 w-48 rounded bg-skeleton"></div>
      <div class="mb-4 mt-2 h-4 w-48 rounded bg-skeleton"></div>

      <div class="mb-4 mt-2 h-6 w-48 rounded bg-skeleton"></div>
      <div class="mb-4 mt-2 h-32 w-full rounded bg-skeleton"></div>
    </div>
  </div>
</template>
