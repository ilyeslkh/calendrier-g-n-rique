<script setup lang="ts">
import DayTitle from '@/components/DayTitle.vue'
import { computeSlotEnd } from '@/utils/TimeSlotUtils'
import CancelledBadge from '@/components/CancelledBadge.vue'
import { Clock } from 'lucide-vue-next'
import { ref, watch } from 'vue'
import moment from 'moment'

export interface Reservation {
  id: number
  date: string
  startHour: string
  nbPersons: number
  cancelled: boolean
}

const props = defineProps(['reservations', 'sortDescending'])

const groupedReservations = ref<{ [key: string]: Reservation[] }>({})

watch(props, () => {
  // Grouper les réservations par jour et trier les mois en ordre décroissant
  if (props.reservations) {
    groupedReservations.value = groupBy(props.reservations as any[], 'date', props.sortDescending)
  }
})

// Fonction pour regrouper un tableau d'objets par une clé donnée
function groupBy(arr: any[], key: string, sortDescending: boolean = false) {
  const grouped = arr.reduce((acc, obj) => {
    const groupKey = moment(obj[key]).format('YYYY-MM-DD')
    acc[groupKey] = acc[groupKey] || []
    acc[groupKey].push(obj)
    return acc
  }, {})

  // Trier les clés (mois) en ordre décroissant si nécessaire toujours dans le groupBy
  const sortedKeys = Object.keys(grouped).sort((a, b) => {
    const dateA = moment(a, 'YYYY-MM-DD').toDate()
    const dateB = moment(b, 'YYYY-MM-DD').toDate()
    return sortDescending ? dateB.getTime() - dateA.getTime() : dateA.getTime() - dateB.getTime()
  })

  // Créer un nouvel objet trié
  const sortedGrouped: { [key: string]: Reservation[] } = {}
  sortedKeys.forEach((key) => {
    sortedGrouped[key] = grouped[key]
  })

  Object.keys(sortedGrouped).forEach((key) =>
    sortedGrouped[key].sort((a, b) => {
      return a.startHour.localeCompare(b.startHour)
    })
  )

  return sortedGrouped
}
</script>
<template>
  <div v-if="Object.keys(groupedReservations).length > 0">
    <ul>
      <!-- Première boucle for pour les jours -->
      <li v-for="(reservations, day, index) in groupedReservations" :key="day">
        <div class="mb-3">
          <hr v-if="index > 0" class="mb-3 mt-6 h-px border-0 bg-gray-200 dark:bg-gray-300" />
          <day-title :day="moment(day, 'YYYY-MM-DD').toDate()"></day-title>
        </div>

        <ul>
          <!-- Deuxième boucle for pour les réservations d'un jour donné -->
          <li v-for="reservation in reservations" :key="reservation.id">
            <div class="mb-3 flex flex-col rounded-lg border border-gray-300 p-5 shadow">
              <p class="mb-3 flex w-fit gap-2 rounded-xl font-bold">
                <Clock />
                {{ moment(reservation.startHour, 'HH:mm:SS').format('HH:mm') }} -
                {{ computeSlotEnd(reservation.startHour) }}
              </p>
              <p class="mb-4 flex items-center gap-2">
                <strong>Statut:</strong> <CancelledBadge :cancelled="reservation.cancelled" /> /
                <strong>Places réservées:</strong> {{ reservation.nbPersons }}
              </p>
              <router-link
                class="text-gray-600"
                :to="
                  '/slot?year=' +
                  reservation.date.split('-')[0] +
                  '&month=' +
                  reservation.date.split('-')[1] +
                  '&day=' +
                  reservation.date.split('-')[2] +
                  '&startHour=' +
                  moment(reservation.startHour, 'HH:mm:SS').format('HH:mm')
                "
              >
                Voir plus →
              </router-link>
            </div>
          </li>
        </ul>
      </li>
    </ul>
  </div>
  <div v-else>
    <p>Aucune réservation trouvée.</p>
  </div>
</template>
