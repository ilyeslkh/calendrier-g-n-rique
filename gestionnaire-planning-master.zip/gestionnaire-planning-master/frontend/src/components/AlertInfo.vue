<script setup lang="ts">
defineProps(['title', 'description'])
</script>
<template>
  <div class="border-l-4 border-green-500 bg-green-100 p-4 text-green-700" role="alert">
    <p class="font-bold">{{ title }}</p>
    <p>{{ description }}</p>
  </div>
</template>
