<script setup lang="ts">
import { useConfigStore } from '@/stores/config'
</script>
<template>
  <div
    class="rounded bg-white bg-cover bg-center bg-no-repeat shadow"
    :style="'background-image: url(\'' + useConfigStore().logo + '\')'"
    alt="Logo de l'Organisation"
  ></div>
</template>
