<script setup lang="ts">
import { CalendarDays } from 'lucide-vue-next'

defineProps(['day'])
</script>

<template>
  <div class="flex items-center gap-2">
    <CalendarDays />
    <h1 class="text-lg font-bold capitalize">
      {{
        day?.toLocaleDateString('fr-FR', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        })
      }}
    </h1>
  </div>
</template>
